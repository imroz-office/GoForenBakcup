from django.shortcuts import render, redirect, get_object_or_404
from django.template.loader import render_to_string
from io import BytesIO
from xhtml2pdf import pisa
from django.utils import timezone
from django.db import connection
from django.db.models import Q, Max
from django.core.exceptions import ValidationError
from django.contrib import messages 
from decimal import Decimal
from .models import *
from urllib.parse import unquote
from django.db import transaction
from django.utils.dateparse import parse_datetime
from django.db.models import Sum
from django.contrib.auth import logout
from django.urls import reverse
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_GET
import logging
from openpyxl import Workbook
from django.http import HttpResponse
from datetime import datetime, timedelta, date
import io
import openpyxl
from django.core.files.storage import FileSystemStorage
import pandas as pd
import json
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
import xlrd
from num2words import num2words
import re
from rest_framework.response import Response
from rest_framework.decorators import api_view
from rest_framework import status
from rest_framework.views import APIView
from django.http import HttpResponseRedirect
from .utils import send_whatsapp_message
import hashlib
import requests
from django.conf import settings
from django.db.models.functions import ExtractYear, ExtractMonth
from dateutil.relativedelta import relativedelta
import base64
import time 
from django.db.models import Max     
from dateutil import parser
from openpyxl.utils import get_column_letter
import random
import string
from django.utils.crypto import get_random_string
from django.contrib.auth import authenticate
from django.utils.dateparse import parse_date
from django.views.decorators.http import require_POST
from django.db.models import Count
from django.utils.timezone import make_aware
from openpyxl.styles import Alignment, Font
import calendar
from openpyxl.utils import get_column_letter
from calendar import monthrange
import os
from django.core.files.base import ContentFile
from django.core.files.storage import default_storage
import mysql.connector 

def get_client_ip(request):
    """Utility to extract IP address from request."""
    x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
    if x_forwarded_for:
        ip = x_forwarded_for.split(',')[0]
    else:
        ip = request.META.get('REMOTE_ADDR')
    return ip

def generate_numeric_unique_id():
    timestamp = int(time.time() * 1000)  # current time in milliseconds
    random_digits = random.randint(100, 999)  # 3-digit random number
    return int(f"{timestamp}{random_digits}")
    
def get_initials(name, limit=3):
    # Split the name into words and get the first letter of each
    words = name.strip().split()
    initials = ''.join(word[0] for word in words[:limit]).upper()
    return initials

def generate_employee_id():
    # Get today's date in YYYYMMDD format
    today_str = datetime.now().strftime('%Y%m%d')
    prefix = f"SIT{today_str}"

    # Find the max employee ID with today's prefix
    last_employee = tbl_employee.objects.filter(employee_id_custom__startswith=prefix).aggregate(
        Max('employee_id_custom')
    )['employee_id_custom__max']

    if last_employee:
        # Extract the counter from the last ID and increment it
        last_counter = int(last_employee[-2:])
        new_counter = last_counter + 1
    else:
        new_counter = 1

    # Format counter as two digits
    counter_str = f"{new_counter:02d}"

    # Construct final employee ID
    return f"{prefix}{counter_str}"

def get_second_and_fourth_saturdays(start_date, end_date):
    from django.db.models import Q
    saturdays = []
    current = start_date
    while current <= end_date:
        if current.weekday() == 5:  
            saturdays.append(current)
        current += timedelta(days=1)

    second_fourth_saturdays = [d for i, d in enumerate(saturdays) if i in (1, 3)]
    result_dates = set()

    for sat_date in second_fourth_saturdays:
        att_on_day = tbl_attendances.objects.filter(date=sat_date)

        full_day_count = 0
        half_day_count = 0

        for att in att_on_day:
            try:
                if att.punch_in and att.punch_in != '0' and att.punch_out and att.punch_out != '0':
                    punch_in = datetime.strptime(att.punch_in, "%H:%M")
                    punch_out = datetime.strptime(att.punch_out, "%H:%M")
                    work_minutes = (punch_out - punch_in).seconds // 60

                    if work_minutes >= 450:  # Full day ~7.5 hrs
                        full_day_count += 1
                    else:
                        half_day_count += 1
                elif (att.punch_in and att.punch_in != '0') or (att.punch_out and att.punch_out != '0'):
                    half_day_count += 1
            except:
                continue

        if half_day_count > full_day_count:
            result_dates.add(sat_date.strftime("%Y-%m-%d"))

    return result_dates

def generate_intern_id():
    # Get today's date in YYYYMMDD format
    today_str = datetime.now().strftime('%Y%m%d')
    prefix = f"SITI{today_str}"

    # Find the max employee ID with today's prefix
    last_employee = tbl_intern.objects.filter(intern_id_custom__startswith=prefix).aggregate(
        Max('intern_id_custom')
    )['intern_id_custom__max']

    if last_employee:
        # Extract the counter from the last ID and increment it
        last_counter = int(last_employee[-2:])
        new_counter = last_counter + 1
    else:
        new_counter = 1

    # Format counter as two digits
    counter_str = f"{new_counter:02d}"

    # Construct final employee ID
    return f"{prefix}{counter_str}"

def log_user_activity(ope, comment, lanti, longti, by_user_id, by_user_name, status):
    # cnx = mysql.connector.connect(user='root', password='', host='localhost', database='shubhamsingh_sit_crm')
    cnx = mysql.connector.connect(user='shubhamsingh_sit_crm', password='kish@1102', host='localhost', database='shubhamsingh_sit_crm')
    cursor = cnx.cursor() 

    insert_query = """
        INSERT INTO tbl_log (ope, comment, lanti, longti, by_user_id, by_user_name, date_time, status)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
    """
    data = (ope, comment, lanti, longti, by_user_id, by_user_name, timezone.now(), status)

    cursor.execute(insert_query, data)
    cnx.commit()
    cursor.close()
    cnx.close()  

  
def plan(request):
    if 'session_id' in request.session:
        session_roleid = request.session.get('session_roleid')
        data = tbl_plan.objects.all()
        
        date_range_filter = request.GET.get('fromDate')
        # to_date = request.GET.get('toDate')
        plan = request.GET.get('plan')
        title = request.GET.get('title')
        price = request.GET.get('price')
        duration = request.GET.get('duration')
        type = request.GET.get('type')
        plan_duration = request.GET.get('plan_duration')
        feature = request.GET.get('feature')
        
        if date_range_filter:
            try:
                start_str, end_str = date_range_filter.split(' - ')
                start_date = parser.parse(start_str.strip())
                end_date = parser.parse(end_str.strip()).replace(hour=23, minute=59, second=59, microsecond=999999)
                data = data.filter(create_time__gte=start_date, create_time__lte=end_date)
            except Exception as e:
                print(f"Date parsing error: {e}")
                
        if plan:
            data = data.filter(plan__icontains=plan)
        if title:
            data = data.filter(title__icontains=title)
        if price:
            data = data.filter(price__icontains=price)
        if duration:
            data = data.filter(duration__icontains=duration)
        if type:
            data = data.filter(type__icontains=type)
        if plan_duration:
            data = data.filter(plan_duration__icontains=plan_duration)
        if feature:
            data = data.filter(feature__icontains=feature)
        
        # query = Q()
            
        # if from_date or to_date:
        #     try:
        #         if from_date:
        #             from_date = datetime.strptime(from_date, '%Y-%m-%d')
        #         else:
        #             from_date = datetime.strptime(to_date, '%Y-%m-%d').replace(hour=0, minute=0, second=0, microsecond=0)
                    
        #         if to_date:
        #             to_date = datetime.strptime(to_date, '%Y-%m-%d').replace(hour=23, minute=59, second=59, microsecond=999999)
        #         else:
        #             to_date = from_date.replace(hour=23, minute=59, second=59, microsecond=999999)
                
        #         if from_date > to_date:
        #             from_date, to_date = to_date, from_date
                    
        #         query &= Q(create_time__range=[from_date, to_date])
                
        #     except ValueError:
        #         pass
            
        # if plan:
        #     query |= Q(plan__icontains=plan)
        # if title:
        #     query |= Q(title__icontains=title)
        # if price:
        #     query |= Q(price__icontains=price)
        # if duration:
        #     query |= Q(duration__icontains=duration)
        # if type:
        #     query |= Q(type__icontains=type)
        # if plan_duration:
        #     query |= Q(plan_duration__icontains=plan_duration)
        # if feature:
        #     query |= Q(feature__icontains=feature)
            
        # data = data.filter(query)
        data = data.order_by('-id')
        
        return render(request,"plan.html",{'data':data,'session_roleid':session_roleid})
    else:
        return redirect(login)
   
def add_plan(request):
    if 'session_id' in request.session:
        session_roleid = request.session.get('session_roleid')
        
        if request.method == 'POST':
            plan = request.POST.get('plan')
            title = request.POST.get('title')
            price = request.POST.get('price')
            duration = request.POST.get('duration')
            type = request.POST.get('type')
            plan_duration = request.POST.get('plan_duration')
            feature_data = request.POST.get('feature_data')
            
            new = tbl_plan(
                plan=plan,
                title=title,
                price=price,
                duration=duration,
                type=type,
                plan_duration=plan_duration,
                feature=feature_data,
            ).save()
            
            ip_address = get_client_ip(request)
            tbl_messages.objects.create(
                message_name = request.session['session_user'],
                change_status=f"Add Puresaas Plan - {title}",
                added_date = timezone.now() + timedelta(hours=5, minutes=30),
                company_id = request.session['company_id'],
                user_id = request.session['session_id'],
                ip_address = ip_address,
            )
            
            return JsonResponse({'status': 'success', 'message': f'Plan {title} added successfully!'})
            
        return render(request,"add_plan.html",{'session_roleid':session_roleid})
    else:
        return redirect(login)
        
def edit_plan(request,id):
    if 'session_id' in request.session:
        session_roleid = request.session.get('session_roleid')
        
        plans = get_object_or_404(tbl_plan, id=id)
    
        if request.method == 'POST':
            plans.plan = request.POST.get('plan')
            plans.title = request.POST.get('title')
            plans.price = request.POST.get('price')
            plans.duration = request.POST.get('duration')
            plans.type = request.POST.get('type')
            plans.plan_duration = request.POST.get('plan_duration')
            plans.feature = request.POST.get('feature_data') 
            
            plans.save()
            
            ip_address = get_client_ip(request)
            tbl_messages.objects.create(
                message_name = request.session['session_user'],
                change_status=f"Edit Puresaas Plan - {plans.title}",
                added_date = timezone.now() + timedelta(hours=5, minutes=30),
                company_id = request.session['company_id'],
                user_id = request.session['session_id'],
                ip_address = ip_address,
            )
            
            return JsonResponse({
                'status': 'success',
                'message': f'Plan {plans.title} has been successfully updated!'
            })

        return render(request, "add_plan.html", {'plans':plans,'is_edit':True,'session_roleid':session_roleid})
    else:
        return redirect(login)
        
def delete_plan(request,id):
    if 'session_id' in request.session:
        data = get_object_or_404(tbl_plan, id=id)
        
        ip_address = get_client_ip(request)
        tbl_messages.objects.create(
            message_name = request.session['session_user'],
            change_status=f"Delete Puresaas Plan - {data.title}",
            added_date = timezone.now() + timedelta(hours=5, minutes=30),
            company_id = request.session['company_id'],
            user_id = request.session['session_id'],
            ip_address = ip_address,
        )
        
        data.delete()
        
        return JsonResponse({'success': True, 'title': data.title})

    return redirect(login) 
    
def view_plan(request,id):
    if 'session_id' in request.session:
        session_roleid = request.session.get('session_roleid')
        plan = get_object_or_404(tbl_plan, id=id)
        return render(request, 'view_plan.html', {'plan': plan,'session_roleid':session_roleid}) 
    else:
        return redirect(login)
        
def plan_view(request):
    try:
        data = tbl_plan.objects.filter(plan_duration="Yearly")
        
        data_list = [
            {
                'id' : tbl_plan.id,
                'plan' : tbl_plan.plan,
                'title' : tbl_plan.title,
                'price' : tbl_plan.price,
                'duration' : tbl_plan.duration,
                'plan_duration' : tbl_plan.plan_duration,
                'type' : tbl_plan.type,
                'feature' : tbl_plan.feature,
                'status' : tbl_plan.status,
                'created_time' : tbl_plan.created_time,
                'add_by_id' : tbl_plan.add_by_id,
            }
            for tbl_plan in data
        ]
        return JsonResponse({'data':data_list},safe=False)
    except Exception as e:
        return JsonResponse({'error':str(e)},status=500)
        
def monthly_plan_view(request):
    try:
        data = tbl_plan.objects.filter(plan_duration="Monthly")
        
        data_list = [
            {
                'id' : tbl_plan.id,
                'plan' : tbl_plan.plan,
                'title' : tbl_plan.title,
                'price' : tbl_plan.price,
                'duration' : tbl_plan.duration,
                'plan_duration' : tbl_plan.plan_duration,
                'type' : tbl_plan.type,
                'feature' : tbl_plan.feature,
                'status' : tbl_plan.status,
                'created_time' : tbl_plan.created_time,
                'add_by_id' : tbl_plan.add_by_id,
            }
            for tbl_plan in data
        ]
        return JsonResponse({'data':data_list},safe=False)
    except Exception as e:
        return JsonResponse({'error':str(e)},status=500)
        
def free_trial(request):
    if 'session_id' in request.session:
        session_roleid = request.session.get('session_roleid')
        
        cnx = mysql.connector.connect(
            user='shubhamsingh_app_tracking_system',
            password='kish@1102',
            host='localhost',
            database='shubhamsingh_app_tracking_system'
        )
        cursor = cnx.cursor(dictionary=True)
        
        cursor.execute("SELECT * FROM all_demo WHERE demo_status = 'Trial'")
        data = cursor.fetchall()
        
        cursor.close()
        cnx.close()
        
        from_date = request.GET.get('fromDate')
        to_date = request.GET.get('toDate')
        name = request.GET.get('name')
        email = request.GET.get('email')
        contact_number = request.GET.get('contact_number')
        
        query = Q()
            
        if from_date or to_date:
            try:
                if from_date:
                    from_date = datetime.strptime(from_date, '%Y-%m-%d')
                else:
                    from_date = datetime.strptime(to_date, '%Y-%m-%d').replace(hour=0, minute=0, second=0, microsecond=0)
                    
                if to_date:
                    to_date = datetime.strptime(to_date, '%Y-%m-%d').replace(hour=23, minute=59, second=59, microsecond=999999)
                else:
                    to_date = from_date.replace(hour=23, minute=59, second=59, microsecond=999999)
                
                if from_date > to_date:
                    from_date, to_date = to_date, from_date
            except ValueError:
                pass
        
        if from_date or to_date:
            data = [item for item in data if from_date <= item['created_date'] <= to_date]
        
        if name:
            data = [item for item in data if name.lower() in item['name'].lower()]
        if email:
            data = [item for item in data if email.lower() in item['email'].lower()]
        if contact_number:
            data = [item for item in data if contact_number in item['contact_number']]
        
        data = sorted(data, key=lambda x: x['id'], reverse=True)
        
        return render(request, "free_trial.html", {'data': data, 'session_roleid': session_roleid})
    else:
        return redirect('login') 
        
def freetrial(request,id):
    if 'session_id' in request.session:
        session_roleid = request.session.get('session_roleid')
        
        cnx = mysql.connector.connect(
            user='shubhamsingh_app_tracking_system',
            password='kish@1102',
            host='localhost',
            database='shubhamsingh_app_tracking_system'
        )
        cursor = cnx.cursor(dictionary=True)
        
        cursor.execute("DELETE FROM all_demo WHERE id = %s", (id,))
        cnx.commit()
        
        cursor.execute("SELECT * FROM all_demo")
        data = cursor.fetchall()
        
        cursor.close()
        cnx.close()
        
        return JsonResponse({'success': True, 'id': id, 'message': "Data deleted successfully."})
    else:
        return redirect(login)   
        
def request_call(request):
    if 'session_id' in request.session:
        session_roleid = request.session.get('session_roleid')
        
        cnx = mysql.connector.connect(
            user='shubhamsingh_app_tracking_system',
            password='kish@1102',
            host='localhost',
            database='shubhamsingh_app_tracking_system'
        )
        cursor = cnx.cursor(dictionary=True)
        
        cursor.execute("SELECT * FROM all_demo WHERE demo_status = 'Callback'")
        data = cursor.fetchall()
        
        cursor.close()
        cnx.close()
        
        from_date = request.GET.get('fromDate')
        to_date = request.GET.get('toDate')
        name = request.GET.get('name')
        email = request.GET.get('email')
        contact_number = request.GET.get('contact_number')
        
        query = Q()
            
        if from_date or to_date:
            try:
                if from_date:
                    from_date = datetime.strptime(from_date, '%Y-%m-%d')
                else:
                    from_date = datetime.strptime(to_date, '%Y-%m-%d').replace(hour=0, minute=0, second=0, microsecond=0)
                    
                if to_date:
                    to_date = datetime.strptime(to_date, '%Y-%m-%d').replace(hour=23, minute=59, second=59, microsecond=999999)
                else:
                    to_date = from_date.replace(hour=23, minute=59, second=59, microsecond=999999)
                
                if from_date > to_date:
                    from_date, to_date = to_date, from_date
            except ValueError:
                pass
        
        if from_date or to_date:
            data = [item for item in data if from_date <= item['created_date'] <= to_date]
        
        if name:
            data = [item for item in data if name.lower() in item['name'].lower()]
        if email:
            data = [item for item in data if email.lower() in item['email'].lower()]
        if contact_number:
            data = [item for item in data if contact_number in item['contact_number']]
        
        data = sorted(data, key=lambda x: x['id'], reverse=True)
        
        return render(request, "request_call.html", {'data': data, 'session_roleid': session_roleid})
    else:
        return redirect('login')
        
def requestcall(request,id):
    if 'session_id' in request.session:
        session_roleid = request.session.get('session_roleid')
        
        cnx = mysql.connector.connect(
            user='shubhamsingh_app_tracking_system',
            password='kish@1102',
            host='localhost',
            database='shubhamsingh_app_tracking_system'
        )
        cursor = cnx.cursor(dictionary=True)
        
        cursor.execute("DELETE FROM all_demo WHERE id = %s", (id,))
        cnx.commit()
        
        cursor.execute("SELECT * FROM all_demo")
        data = cursor.fetchall()
        
        cursor.close()
        cnx.close()
        
        return JsonResponse({'success': True, 'id': id, 'message': "Data deleted successfully."})
    else:
        return redirect(login)   
        
def view_call(request, id):
    if 'session_id' in request.session:
        session_roleid = request.session.get('session_roleid')

        cnx = mysql.connector.connect(
            user='shubhamsingh_app_tracking_system',
            password='kish@1102',
            host='localhost',
            database='shubhamsingh_app_tracking_system'
        )
        cursor = cnx.cursor(dictionary=True)

        cursor.execute("SELECT * FROM all_demo WHERE id = %s", (id,))
        data = cursor.fetchone()
        
        cursor.close()
        cnx.close()

        if data:
            return render(request, "view_call.html", {'data': data, 'session_roleid': session_roleid})
        else:
            return redirect(reverse('some_error_page')) 
    else:
        return redirect('login')

        
def price_quote(request):
    if 'session_id' in request.session:
        session_roleid = request.session.get('session_roleid')
        
        cnx = mysql.connector.connect(
            user='shubhamsingh_app_tracking_system',
            password='kish@1102',
            host='localhost',
            database='shubhamsingh_app_tracking_system'
        )
        cursor = cnx.cursor(dictionary=True)
        
        cursor.execute("SELECT * FROM all_demo WHERE demo_status = 'Quote'")
        data = cursor.fetchall()
        
        cursor.close()
        cnx.close()
        
        from_date = request.GET.get('fromDate')
        to_date = request.GET.get('toDate')
        name = request.GET.get('name')
        email = request.GET.get('email')
        contact_number = request.GET.get('contact_number')
        
        query = Q()
            
        if from_date or to_date:
            try:
                if from_date:
                    from_date = datetime.strptime(from_date, '%Y-%m-%d')
                else:
                    from_date = datetime.strptime(to_date, '%Y-%m-%d').replace(hour=0, minute=0, second=0, microsecond=0)
                    
                if to_date:
                    to_date = datetime.strptime(to_date, '%Y-%m-%d').replace(hour=23, minute=59, second=59, microsecond=999999)
                else:
                    to_date = from_date.replace(hour=23, minute=59, second=59, microsecond=999999)
                
                if from_date > to_date:
                    from_date, to_date = to_date, from_date
            except ValueError:
                pass
        
        if from_date or to_date:
            data = [item for item in data if from_date <= item['created_date'] <= to_date]
        
        if name:
            data = [item for item in data if name.lower() in item['name'].lower()]
        if email:
            data = [item for item in data if email.lower() in item['email'].lower()]
        if contact_number:
            data = [item for item in data if contact_number in item['contact_number']]
        
        data = sorted(data, key=lambda x: x['id'], reverse=True)
        
        return render(request, "price_quote.html", {'data': data, 'session_roleid': session_roleid})
    else:
        return redirect('login')
        
def pricequote(request,id):
    if 'session_id' in request.session:
        session_roleid = request.session.get('session_roleid')
        
        cnx = mysql.connector.connect(
            user='shubhamsingh_app_tracking_system',
            password='kish@1102',
            host='localhost',
            database='shubhamsingh_app_tracking_system'
        )
        cursor = cnx.cursor(dictionary=True)
        
        cursor.execute("DELETE FROM all_demo WHERE id = %s", (id,))
        cnx.commit()
        
        cursor.execute("SELECT * FROM all_demo")
        data = cursor.fetchall()
        
        cursor.close()
        cnx.close()
        
        return JsonResponse({'success': True, 'id': id, 'message': "Data deleted successfully."})
    else:
        return redirect(login)
        
def view_quote(request, id):
    if 'session_id' in request.session:
        session_roleid = request.session.get('session_roleid')

        cnx = mysql.connector.connect(
            user='shubhamsingh_app_tracking_system',
            password='kish@1102',
            host='localhost',
            database='shubhamsingh_app_tracking_system'
        )
        cursor = cnx.cursor(dictionary=True)

        cursor.execute("SELECT * FROM all_demo WHERE id = %s", (id,))
        data = cursor.fetchone()
        
        cursor.close()
        cnx.close()

        if data:
            return render(request, "view_quote.html", {'data': data, 'session_roleid': session_roleid})
        else:
            return redirect(reverse('some_error_page')) 
    else:
        return redirect('login')
        
def book_demo(request):
    if 'session_id' in request.session:
        session_roleid = request.session.get('session_roleid')
        
        cnx = mysql.connector.connect(
            user='shubhamsingh_app_tracking_system',
            password='kish@1102',
            host='localhost',
            database='shubhamsingh_app_tracking_system'
        )
        cursor = cnx.cursor(dictionary=True)
        
        cursor.execute("SELECT * FROM book_demo ")
        data = cursor.fetchall()
        
        cursor.close()
        cnx.close()
        
        from_date = request.GET.get('fromDate')
        to_date = request.GET.get('toDate')
        name = request.GET.get('name')
        email = request.GET.get('email')
        number = request.GET.get('number')
        
        query = Q()
            
        if from_date or to_date:
            try:
                if from_date:
                    from_date = datetime.strptime(from_date, '%Y-%m-%d')
                else:
                    from_date = datetime.strptime(to_date, '%Y-%m-%d').replace(hour=0, minute=0, second=0, microsecond=0)
                    
                if to_date:
                    to_date = datetime.strptime(to_date, '%Y-%m-%d').replace(hour=23, minute=59, second=59, microsecond=999999)
                else:
                    to_date = from_date.replace(hour=23, minute=59, second=59, microsecond=999999)
                
                if from_date > to_date:
                    from_date, to_date = to_date, from_date
            except ValueError:
                pass
        
        if from_date or to_date:
            data = [item for item in data if from_date <= item['created_date'] <= to_date]
        
        if name:
            data = [item for item in data if name.lower() in item['name'].lower()]
        if email:
            data = [item for item in data if email.lower() in item['email'].lower()]
        if number:
            data = [item for item in data if number in item['number']]
        
        data = sorted(data, key=lambda x: x['id'], reverse=True)
        
        return render(request, "book_demo.html", {'data': data, 'session_roleid': session_roleid})
    else:
        return redirect('login')
        
def bookdemo(request,id):
    if 'session_id' in request.session:
        session_roleid = request.session.get('session_roleid')
        
        cnx = mysql.connector.connect(
            user='shubhamsingh_app_tracking_system',
            password='kish@1102',
            host='localhost',
            database='shubhamsingh_app_tracking_system'
        )
        cursor = cnx.cursor(dictionary=True)
        
        cursor.execute("DELETE FROM book_demo WHERE id = %s", (id,))
        cnx.commit()
        
        cursor.execute("SELECT * FROM book_demo")
        data = cursor.fetchall()
        
        cursor.close()
        cnx.close()
        
        return JsonResponse({'success': True, 'id': id, 'message': "Data deleted successfully."})
    else:
        return redirect(login)
        
def ask_question(request):
    if 'session_id' in request.session:
        session_roleid = request.session.get('session_roleid')
        
        cnx = mysql.connector.connect(
            user='shubhamsingh_app_tracking_system',
            password='kish@1102',
            host='localhost',
            database='shubhamsingh_app_tracking_system'
        )
        cursor = cnx.cursor(dictionary=True)
        
        cursor.execute("SELECT * FROM ask_question")
        data = cursor.fetchall()
        
        cursor.close()
        cnx.close()
        
        from_date = request.GET.get('fromDate')
        to_date = request.GET.get('toDate')
        name = request.GET.get('name')
        email = request.GET.get('email')
        message = request.GET.get('message')
        
        query = Q()
            
        if from_date or to_date:
            try:
                if from_date:
                    from_date = datetime.strptime(from_date, '%Y-%m-%d')
                else:
                    from_date = datetime.strptime(to_date, '%Y-%m-%d').replace(hour=0, minute=0, second=0, microsecond=0)
                    
                if to_date:
                    to_date = datetime.strptime(to_date, '%Y-%m-%d').replace(hour=23, minute=59, second=59, microsecond=999999)
                else:
                    to_date = from_date.replace(hour=23, minute=59, second=59, microsecond=999999)
                
                if from_date > to_date:
                    from_date, to_date = to_date, from_date
            except ValueError:
                pass
        
        if from_date or to_date:
            data = [item for item in data if from_date <= item['created_date'] <= to_date]
        
        if name:
            data = [item for item in data if name.lower() in item['name'].lower()]
        if email:
            data = [item for item in data if email.lower() in item['email'].lower()]
        if message:
            data = [item for item in data if message in item['message']]
        
        data = sorted(data, key=lambda x: x['id'], reverse=True)
        
        return render(request, "ask_question.html", {'data': data, 'session_roleid': session_roleid})
    else:
        return redirect('login')
        
def askquestion(request,id):
    if 'session_id' in request.session:
        session_roleid = request.session.get('session_roleid')
        
        cnx = mysql.connector.connect(
            user='shubhamsingh_app_tracking_system',
            password='kish@1102',
            host='localhost',
            database='shubhamsingh_app_tracking_system'
        )
        cursor = cnx.cursor(dictionary=True)
        
        cursor.execute("DELETE FROM ask_question WHERE id = %s", (id,))
        cnx.commit()
        
        cursor.execute("SELECT * FROM ask_question")
        data = cursor.fetchall()
        
        cursor.close()
        cnx.close()
        
        return JsonResponse({'success': True, 'id': id, 'message': "Data deleted successfully."})
    else:
        return redirect(login)
        
        
def blogs_comment(request):
    if 'session_id' in request.session:
        session_roleid = request.session.get('session_roleid')
        
        cnx = mysql.connector.connect(
            user='shubhamsingh_app_tracking_system',
            password='kish@1102',
            host='localhost',
            database='shubhamsingh_app_tracking_system'
        )
        cursor = cnx.cursor(dictionary=True)
        
        cursor.execute("SELECT * FROM blog_comment ")
        data = cursor.fetchall()
        
        cursor.close()
        cnx.close()
        
        from_date = request.GET.get('fromDate')
        to_date = request.GET.get('toDate')
        name = request.GET.get('name')
        email = request.GET.get('email')
        message = request.GET.get('message')
        
        query = Q()
            
        if from_date or to_date:
            try:
                if from_date:
                    from_date = datetime.strptime(from_date, '%Y-%m-%d')
                else:
                    from_date = datetime.strptime(to_date, '%Y-%m-%d').replace(hour=0, minute=0, second=0, microsecond=0)
                    
                if to_date:
                    to_date = datetime.strptime(to_date, '%Y-%m-%d').replace(hour=23, minute=59, second=59, microsecond=999999)
                else:
                    to_date = from_date.replace(hour=23, minute=59, second=59, microsecond=999999)
                
                if from_date > to_date:
                    from_date, to_date = to_date, from_date
            except ValueError:
                pass
        
        if from_date or to_date:
            data = [item for item in data if from_date <= item['created_date'] <= to_date]
        
        if name:
            data = [item for item in data if name.lower() in item['name'].lower()]
        if email:
            data = [item for item in data if email.lower() in item['email'].lower()]
        if message:
            data = [item for item in data if message in item['message']]
        
        data = sorted(data, key=lambda x: x['id'], reverse=True)
        
        return render(request, "blogs_comment.html", {'data': data, 'session_roleid': session_roleid})
    else:
        return redirect('login')
        
def blogscomment(request,id):
    if 'session_id' in request.session:
        session_roleid = request.session.get('session_roleid')
        
        cnx = mysql.connector.connect(
            user='shubhamsingh_app_tracking_system',
            password='kish@1102',
            host='localhost',
            database='shubhamsingh_app_tracking_system'
        )
        cursor = cnx.cursor(dictionary=True)
        
        cursor.execute("DELETE FROM blog_comment WHERE id = %s", (id,))
        cnx.commit()
        
        cursor.execute("SELECT * FROM blog_comment")
        data = cursor.fetchall()
        
        cursor.close()
        cnx.close()
        
        return JsonResponse({'success': True, 'id': id, 'message': "Data deleted successfully."})
    else:
        return redirect(login)
        
def message(request):
    if 'session_id' in request.session:
        session_roleid = request.session.get('session_roleid')
        
        cnx = mysql.connector.connect(
            user='shubhamsingh_app_tracking_system',
            password='kish@1102',
            host='localhost',
            database='shubhamsingh_app_tracking_system'
        )
        cursor = cnx.cursor(dictionary=True)
        
        cursor.execute("SELECT * FROM inq_message ")
        data = cursor.fetchall()
        
        cursor.close()
        cnx.close()
        
        from_date = request.GET.get('fromDate')
        to_date = request.GET.get('toDate')
        name = request.GET.get('name')
        email = request.GET.get('email')
        subject = request.GET.get('subject')
        message = request.GET.get('message')
        
        query = Q()
            
        if from_date or to_date:
            try:
                if from_date:
                    from_date = datetime.strptime(from_date, '%Y-%m-%d')
                else:
                    from_date = datetime.strptime(to_date, '%Y-%m-%d').replace(hour=0, minute=0, second=0, microsecond=0)
                    
                if to_date:
                    to_date = datetime.strptime(to_date, '%Y-%m-%d').replace(hour=23, minute=59, second=59, microsecond=999999)
                else:
                    to_date = from_date.replace(hour=23, minute=59, second=59, microsecond=999999)
                
                if from_date > to_date:
                    from_date, to_date = to_date, from_date
            except ValueError:
                pass
        
        if from_date or to_date:
            data = [item for item in data if from_date <= item['created_date'] <= to_date]
        
        if name:
            data = [item for item in data if name.lower() in item['name'].lower()]
        if email:
            data = [item for item in data if email.lower() in item['email'].lower()]
        if subject:
            data = [item for item in data if subject in item['subject']]
        if message:
            data = [item for item in data if message in item['message']]
        
        data = sorted(data, key=lambda x: x['id'], reverse=True)
        
        return render(request, "message.html", {'data': data, 'session_roleid': session_roleid})
    else:
        return redirect('login')
        
def del_message(request,id):
    if 'session_id' in request.session:
        session_roleid = request.session.get('session_roleid')
        
        cnx = mysql.connector.connect(
            user='shubhamsingh_app_tracking_system',
            password='kish@1102',
            host='localhost',
            database='shubhamsingh_app_tracking_system'
        )
        cursor = cnx.cursor(dictionary=True)
        
        cursor.execute("DELETE FROM inq_message WHERE id = %s", (id,))
        cnx.commit()
        
        cursor.execute("SELECT * FROM inq_message")
        data = cursor.fetchall()
        
        cursor.close()
        cnx.close()
        
        return JsonResponse({'success': True, 'id': id, 'message': "Data deleted successfully."})
    else:
        return redirect(login)
        
def all_demo(request):
    if 'session_id' in request.session:
        session_roleid = request.session.get('session_roleid')
        
        cnx = mysql.connector.connect(
            user='shubhamsingh_app_tracking_system',
            password='kish@1102',
            host='localhost',
            database='shubhamsingh_app_tracking_system'
        )
        cursor = cnx.cursor(dictionary=True)
        
        cursor.execute("SELECT * FROM all_inquiry ")
        data = cursor.fetchall()
        
        cursor.close()
        cnx.close()
        
        from_date = request.GET.get('fromDate')
        to_date = request.GET.get('toDate')
        types = request.GET.get('types')
        name = request.GET.get('name')
        number = request.GET.get('number')
        email = request.GET.get('email')
        company_name = request.GET.get('company_name')
        no_emp = request.GET.get('no_emp')
        city = request.GET.get('city')
        state = request.GET.get('state')
        zipcode = request.GET.get('zipcode')
        
        query = Q()
            
        if from_date or to_date:
            try:
                if from_date:
                    from_date = datetime.strptime(from_date, '%Y-%m-%d')
                else:
                    from_date = datetime.strptime(to_date, '%Y-%m-%d').replace(hour=0, minute=0, second=0, microsecond=0)
                    
                if to_date:
                    to_date = datetime.strptime(to_date, '%Y-%m-%d').replace(hour=23, minute=59, second=59, microsecond=999999)
                else:
                    to_date = from_date.replace(hour=23, minute=59, second=59, microsecond=999999)
                
                if from_date > to_date:
                    from_date, to_date = to_date, from_date
            except ValueError:
                pass
        
        if from_date or to_date:
            data = [item for item in data if from_date <= item['created_date'] <= to_date]
            
        if types:
            data = [item for item in data if types.lower() in item['types'].lower()]
        if name:
            data = [item for item in data if name.lower() in item['name'].lower()]
        if number:
            data = [item for item in data if number.lower() in item['number'].lower()]
        if email:
            data = [item for item in data if email.lower() in item['email'].lower()]
        if company_name:
            data = [item for item in data if company_name.lower() in item['company_name'].lower()]
        if no_emp:
            data = [item for item in data if no_emp.lower() in item['no_emp'].lower()]
        if city:
            data = [item for item in data if city.lower() in item['city'].lower()]
        if state:
            data = [item for item in data if state.lower() in item['state'].lower()]
        if zipcode:
            data = [item for item in data if zipcode in item['zipcode']]
        
        data = sorted(data, key=lambda x: x['id'], reverse=True)
        
        return render(request, "all_demo.html", {'data': data, 'session_roleid': session_roleid})
    else:
        return redirect('login') 
        
def del_all_demo(request,id):
    if 'session_id' in request.session:
        session_roleid = request.session.get('session_roleid')
        
        cnx = mysql.connector.connect(
            user='shubhamsingh_app_tracking_system',
            password='kish@1102',
            host='localhost',
            database='shubhamsingh_app_tracking_system'
        )
        cursor = cnx.cursor(dictionary=True)
        
        cursor.execute("DELETE FROM all_inquiry WHERE id = %s", (id,))
        cnx.commit()
        
        cursor.execute("SELECT * FROM all_inquiry")
        data = cursor.fetchall()
        
        cursor.close()
        cnx.close()
        
        return JsonResponse({'success': True, 'id': id, 'message': "Data deleted successfully."})
    else:
        return redirect(login)
        
def view_demo(request, id):
    if 'session_id' in request.session:
        session_roleid = request.session.get('session_roleid')

        cnx = mysql.connector.connect(
            user='shubhamsingh_app_tracking_system',
            password='kish@1102',
            host='localhost',
            database='shubhamsingh_app_tracking_system'
        )
        cursor = cnx.cursor(dictionary=True)

        cursor.execute("SELECT * FROM all_inquiry WHERE id = %s", (id,)) 
        data = cursor.fetchone()
        
        cursor.close()
        cnx.close()

        if data:
            return render(request, "view_demo.html", {'data': data, 'session_roleid': session_roleid})
        else:
            return redirect(reverse('some_error_page')) 
    else:
        return redirect('login')
        
def demo_convert_lead(request, id):
    if 'session_id' not in request.session:
        return redirect('login')

    # Connect to the MySQL DB and fetch the inquiry by ID
    cnx = mysql.connector.connect(
        user='shubhamsingh_app_tracking_system',
        password='kish@1102',
        host='localhost',
        database='shubhamsingh_app_tracking_system'
    )
    cursor = cnx.cursor(dictionary=True)
    
    cursor.execute("SELECT * FROM all_inquiry WHERE id = %s", (id,))
    inquiry = cursor.fetchone()
    
    if not inquiry:
        cursor.close()
        cnx.close()
        return redirect('all_demo')  # or show error
    
    # Map inquiry data to tbl_lead model
    lead = tbl_lead(
        c_name=inquiry.get('name'),
        mobile=inquiry.get('number'),
        email=inquiry.get('email'),
        business_name=inquiry.get('company_name'),
        city=inquiry.get('city'),
        state=inquiry.get('state'),
        pincode=inquiry.get('zipcode'),
        source='Puresaas',
        segment=inquiry.get('types'),
        create_time=timezone.now() + timedelta(hours=5, minutes=30),
        add_by_id=request.session.get('session_id'),
        add_by_name=request.session.get('session_user'),
    )
    
    lead.save()

    cursor.execute("DELETE FROM all_inquiry WHERE id = %s", (id,))
    cnx.commit()

    cursor.close()
    cnx.close()
    
    messages.success(request, 'Lead has been successfully converted!')

    return redirect('all_demo')
    
def book_bulk_convert(request):
    if request.method == 'POST':
        ids = request.POST.getlist('selected_leads')
        if not ids:
            messages.error(request, 'No inquiries selected.')
            return redirect('all_demo')

        cnx = mysql.connector.connect(
            user='shubhamsingh_app_tracking_system',
            password='kish@1102',
            host='localhost',
            database='shubhamsingh_app_tracking_system'
        )
        cursor = cnx.cursor(dictionary=True)

        for lead_id in ids:
            cursor.execute("SELECT * FROM all_inquiry WHERE id = %s", (lead_id,))
            inquiry = cursor.fetchone()

            if inquiry:
                lead = tbl_lead(
                    c_name=inquiry.get('name'),
                    mobile=inquiry.get('number'),
                    email=inquiry.get('email'),
                    business_name=inquiry.get('company_name'),
                    city=inquiry.get('city'),
                    state=inquiry.get('state'),
                    pincode=inquiry.get('zipcode'),
                    source='Puresaas',
                    segment=inquiry.get('types'),
                    create_time=timezone.now() + timedelta(hours=5, minutes=30),
                    add_by_id=request.session.get('session_id'),
                    add_by_name=request.session.get('session_user'),
                )
                lead.save()

                # Delete original inquiry
                cursor.execute("DELETE FROM all_inquiry WHERE id = %s", (lead_id,))
        
        cnx.commit()
        cursor.close()
        cnx.close()

        messages.success(request, 'Selected inquiries have been successfully converted into leads.')
        return redirect('all_demo')
    else:
        return redirect('all_demo')   
        
def puresaas_list(request):
    if 'session_id' in request.session:
        session_roleid = request.session.get('session_roleid')

        # Connect to MySQL to get users
        cnx = mysql.connector.connect(
            user='shubhamsingh_app_tracking_system',
            password='kish@1102',
            host='localhost',
            database='shubhamsingh_app_tracking_system'
        )
        cursor = cnx.cursor(dictionary=True)
        cursor.execute("SELECT * FROM tbl_users")
        puresaas_data = cursor.fetchall()

        # Extract user IDs from users
        user_ids = [user['userId'] for user in puresaas_data]

        # Fetch related orders using Django ORM
        orders = tbl_order.objects.filter(user_id__in=user_ids)
        orders_by_user = {}
        for order in orders:
            orders_by_user.setdefault(order.user_id, []).append(order)

        # Fetch plan data from tbl_plan
        plan_ids = [order.plan_id for order in orders]
        plans = tbl_plan.objects.filter(id__in=plan_ids)

        # Create a dictionary of plan data for quick lookup
        plan_dict = {plan.id: plan for plan in plans}

        # Merge user data with their orders and plans
        merged_data = []
        for user in puresaas_data:
            user_orders = orders_by_user.get(user['userId'], [])
            for order in user_orders:
                plan_details = plan_dict.get(order.plan_id)  # Get the plan for this order
                merged_data.append({
                    'user': user,
                    'order': order,
                    'plan': plan_details  # Add plan details
                })

        # Close database connection
        cursor.close()
        cnx.close()

        return render(request, "puresaas-list.html", {
            'merged_data': merged_data,
            'session_roleid': session_roleid
        })
    else:
        return redirect('login')

 
        
def puresaas_renewal(request):
    if 'session_id' in request.session:
        session_roleid = request.session.get('session_roleid')
        
        today = timezone.now().date()
        puresaas_data = tbl_order.objects.filter(end_date__date=today)
        
        plan_ids = puresaas_data.values_list('plan_id', flat=True)
        plans = tbl_plan.objects.filter(id__in=plan_ids)
        
        plan_dict = {plan.id: plan for plan in plans}
        
        for order in puresaas_data:
            order.plan_details = plan_dict.get(order.plan_id)
            
        cnx = mysql.connector.connect(
            user='shubhamsingh_app_tracking_system',
            password='kish@1102',
            host='localhost',
            database='shubhamsingh_app_tracking_system'
        )
        cursor = cnx.cursor(dictionary=True)
        cursor.execute("SELECT * FROM tbl_users")
        users_data = cursor.fetchall()

        cursor.close()
        cnx.close()

        merged_data = []

        user_dict = {user['userId']: user for user in users_data}

        for order in puresaas_data:
            user = user_dict.get(order.user_id)
            if user:
                merged_data.append({
                    'order': order,
                    'user': user
                })
        
        return render(request, "puresaas-renewal.html", {
            'puresaas_data': merged_data,
            'session_roleid': session_roleid
        })
    else:
        return redirect('login')
        
def puresaas_renewal_week(request):
    if 'session_id' in request.session:
        session_roleid = request.session.get('session_roleid')
        
        today = timezone.now().date()
        seven_days_later = today + timedelta(days=7)
        puresaas_data = tbl_order.objects.filter(end_date__date__gte=today, end_date__date__lte=seven_days_later)
        
        plan_ids = puresaas_data.values_list('plan_id', flat=True)
        plans = tbl_plan.objects.filter(id__in=plan_ids)
        
        plan_dict = {plan.id: plan for plan in plans}
        
        for order in puresaas_data:
            order.plan_details = plan_dict.get(order.plan_id)
            
        cnx = mysql.connector.connect(
            user='shubhamsingh_app_tracking_system',
            password='kish@1102',
            host='localhost',
            database='shubhamsingh_app_tracking_system'
        )
        cursor = cnx.cursor(dictionary=True)
        cursor.execute("SELECT * FROM tbl_users")
        users_data = cursor.fetchall()

        cursor.close()
        cnx.close()

        merged_data = []

        user_dict = {user['userId']: user for user in users_data}

        for order in puresaas_data:
            user = user_dict.get(order.user_id)
            if user:
                merged_data.append({
                    'order': order,
                    'user': user
                })
        
        return render(request, "puresaas-renewal.html", {
            'puresaas_data': merged_data,
            'session_roleid': session_roleid
        })
    else:
        return redirect('login')

def puresaas_view(request,id):
    if 'session_id' in request.session:
        session_roleid = request.session.get('session_roleid')
        
        cnx = mysql.connector.connect(
            user='puresaas_db',
            password='kish@1102',
            host='localhost',
            database='puresaas_db'
        )
        cursor = cnx.cursor(dictionary=True)
        
        cursor.execute("SELECT * FROM tbl_jewellers WHERE id = %s", (id,))
        jeweller_data = cursor.fetchone()

        cursor.close()
        cnx.close()
        
        return render(request,"puresaas-view.html",{'jeweller_data':jeweller_data,'session_roleid':session_roleid})
    else:
        return redirect(login)
        
def pure_view(request,id):
    if 'session_id' in request.session:
        session_roleid = request.session.get('session_roleid')
        
        cnx = mysql.connector.connect(
            user='puresaas_db',
            password='kish@1102',
            host='localhost',
            database='puresaas_db'
        )
        cursor = cnx.cursor(dictionary=True)
        
        cursor.execute("SELECT * FROM tbl_jewellers WHERE id = %s", (id,))
        jeweller_data = cursor.fetchone()

        cursor.close()
        cnx.close()
        
        return render(request,"pure-view.html",{'jeweller_data':jeweller_data,'session_roleid':session_roleid})
    else:
        return redirect(login)
        
def puresaas_client(request,id):
    if 'session_id' in request.session:
        session_roleid = request.session.get('session_roleid')
        session_id = request.session.get('session_id')
        
        cnx = mysql.connector.connect(
            user='puresaas_db',
            password='kish@1102',
            host='localhost',
            database='puresaas_db'
        )
        cursor = cnx.cursor(dictionary=True)
        
        cursor.execute("SELECT * FROM tbl_jewellers WHERE id = %s", (id,))
        puresaas_data = cursor.fetchall()
        
        for jeweller in puresaas_data:
            master_client_data = {
                'add_by_id': session_id,
                'name': jeweller.get('full_name'),
                'email': jeweller.get('email'),
                'comp_name': jeweller.get('firm_name'),
                'mobile': jeweller.get('mobile'),
                'address': jeweller.get('home_address1'),
                'client_type': 'Puresaas', 
                'billing_add': jeweller.get('bill_address1'),
                'area': jeweller.get('home_city'),
                'city': jeweller.get('home_city'),
                'state': jeweller.get('home_state'),
                'country': jeweller.get('home_country'),
                'gst_number': jeweller.get('gst_no'),
                'service_type': jeweller.get('package'), 
                'Plan': jeweller.get('package'),
                'remark': jeweller.get('purchase'), 
                'p_s_date': jeweller.get('plan_s_date'),
                'p_e_date': jeweller.get('plan_e_date'),
                'start_date': jeweller.get('plan_s_date'),
                'expire_date': jeweller.get('plan_e_date'),
                'create_time': timezone.now() + timedelta(hours=5, minutes=30),
            }
            
            master_client.objects.create(**master_client_data)
            
            cursor.execute("UPDATE tbl_jewellers SET crm_add_client = 'Client Added' WHERE id = %s", (id,))
            cnx.commit()
            
        cursor.close()
        cnx.close()
        
        return redirect('puresaas_list')
    else:
        return redirect(login)

@api_view(['POST'])
def sit_career(request):
    try:
        if request.method == 'POST': 
            from_filling = request.data.get('from_filling', "")
            full_name = request.data.get('full_name')
            email = request.data.get('email')
            mobile = request.data.get('mobile')
            qualification = request.data.get('qualification')
            applying_for = request.data.get('applying_for') 
            preferred_technology = request.data.get('preferred_technology')
            clg_name = request.data.get('clg_name')
            internship_duration = request.data.get('internship_duration')
            uploaded_cv = request.data.get('uploaded_cv')
            last_company = request.data.get('last_company')
            last_CTC = request.data.get('last_CTC')
            expected_salary = request.data.get('expected_salary')
            applied_from_company = request.data.get('applied_from_company')
            years_of_exp = request.data.get('years_of_exp') or ""
    
            current_time = timezone.now() + timedelta(hours=5, minutes=30)
            
            applied_from_company = applied_from_company.title()

            new = tbl_hiring.objects.create(
                full_name=full_name,
                email=email,
                years_of_exp=years_of_exp,
                mobile=mobile,
                qualification=qualification,
                applying_for=applying_for,
                preferred_technology=preferred_technology,
                clg_name=clg_name,
                internship_duration=internship_duration,
                uploaded_cv=uploaded_cv,
                last_company=last_company,
                last_CTC=last_CTC,
                expected_salary=expected_salary,
                applied_from_company=applied_from_company,
                status="pending",
                apply_date=current_time.strftime("%Y-%m-%d"),
                apply_time=current_time.strftime("%H:%M:%S"),
            )
    
            # if mobile:
                # phone = f"91{mobile[-10:]}"
                # send_whatsapp_message(phone, message_type='template', template_name="on_apply", template_params=[full_name])
            if from_filling == "NEW_CRM":
                return JsonResponse({'status': 'success', 'message': 'Applicant submitted successfully'})

            return Response({"success": f"Data '{full_name}' added successfully!"}, status=status.HTTP_201_CREATED)
    except Exception as e:
        return Response({"error": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

from django.db.models import Q
from dateutil import parser 
from django.utils.timezone import now

def hiring_list(request):
    company_list = master_company.objects.all()
    applicant_status = tbl_applicant_status.objects.all()

    if 'session_id' in request.session:
        session_roleid = request.session.get('session_roleid')

        hiring = tbl_hiring.objects.all().order_by("-hiring_id")

        # Filters from GET request
        date_range_filter = request.GET.get('fromDate')
        full_name = request.GET.get('full_name')
        email = request.GET.get('email')
        mobile = request.GET.get('mobile')
        emp_type = request.GET.get('emp_type')
        join_date = request.GET.get('join_date')
        date_of_birth = request.GET.get('date_of_birth')
        applied_from_company = request.GET.get('applied_from_company')
        applying_for = request.GET.get('applying_for')
        status = request.GET.get('status')
        preferred_technology = request.GET.get('preferred_technology')
        apply_date = request.GET.get('apply_date')
        apply_time = request.GET.get('apply_time')

        # Apply filters
        if date_range_filter:
            try:
                start_str, end_str = date_range_filter.split(' - ')
                start_date = parser.parse(start_str.strip())
                end_date = parser.parse(end_str.strip()).replace(hour=23, minute=59, second=59)
                hiring = hiring.filter(created_at__range=(start_date, end_date))
            except Exception as e:
                print(f"Date parsing error: {e}")

        if full_name:
            hiring = hiring.filter(full_name__icontains=full_name)
        if email:
            hiring = hiring.filter(email__icontains=email)
        if mobile:
            hiring = hiring.filter(mobile__icontains=mobile)
        if emp_type:
            hiring = hiring.filter(applying_for__icontains=emp_type)
        if join_date:
            hiring = hiring.filter(joining_date__icontains=join_date)
        if date_of_birth:
            hiring = hiring.filter(date_of_birth__icontains=date_of_birth)
        if applied_from_company:
            hiring = hiring.filter(applied_from_company__icontains=applied_from_company)
        if applying_for:
            hiring = hiring.filter(applying_for__icontains=applying_for)
        if status:
            hiring = hiring.filter(status__icontains=status)
        if preferred_technology:
            hiring = hiring.filter(preferred_technology__icontains=preferred_technology)
        if apply_date:
            hiring = hiring.filter(apply_date__icontains=apply_date)
        if apply_time:
            hiring = hiring.filter(apply_time__icontains=apply_time)

        # Count of all statuses
        status_counts = tbl_hiring.objects.values('status').annotate(count=Count('status')).order_by('status')

        # Count of interviews scheduled today
        today = now().date()
        interview_scheduled_today_count = tbl_hiring.objects.filter(
            status='interview scheduled',
            interview_date=today
        ).count()
        total_applicants = hiring.count()
        return render(request, "hiring_list.html", {
            'session_roleid': session_roleid,
            'hiring': hiring,
            'total_applicants': total_applicants,
            'company_list': company_list,
            'applicant_status': applicant_status,
            'status_counts': status_counts,
            'interview_scheduled_today_count': interview_scheduled_today_count,
        })

    else:
        return redirect(login)

def view_hiring(request, id):
    if 'session_id' in request.session:
        session_roleid = request.session.get('session_roleid')

        try:
            statuses = tbl_applicant_status.objects.all().order_by("id")
            hiring = tbl_hiring.objects.get(hiring_id=id)
            return render(request, 'hiring_view.html', {
                'hiring': hiring,
                'statuses': statuses,
                'session_roleid': session_roleid,
            })
        except tbl_hiring.DoesNotExist:
            return redirect('hiring_list',)
    else:
        return redirect(login)

def hiring_status(request, id):
    if 'session_id' in request.session:
        session_roleid = request.session.get('session_roleid')

        try:
            users = tbl_users2.objects.all()
            statuses = tbl_applicant_status.objects.all().order_by("id")
            hiring = tbl_hiring.objects.get(hiring_id=id)
            return render(request, 'hiring_status.html', {
                'users': users,
                'hiring': hiring,
                'statuses': statuses,
                'session_roleid': session_roleid,
            })
        except tbl_hiring.DoesNotExist:
            return redirect('hiring_list',)
    else:
        return redirect(login)

def update_applicant_status(request, id):
    hiring = get_object_or_404(tbl_hiring, hiring_id=id)

    if request.method == 'POST':
        status = request.POST.get('status')
        hiring.status = status

        template_name = ''
        template_params = []
        location = "Rajhans Platinum Plaza, Adajan, 410 - 412, Palanpur Canal Rd, near NEW LP SAVANI SCHOOL, Surat, Gujarat 395009"

        if status == 'interview scheduled':
            hiring.interview_date = request.POST.get('interview_date') or None
            hiring.interview_time = request.POST.get('interview_time') or None
            template_name = 'interview_message'
            try:
                formatted_interview_date = datetime.strptime(hiring.interview_date, "%Y-%m-%d").strftime("%d-%m-%Y")
            except (ValueError, TypeError):
                formatted_interview_date = "To be announced"
            template_params = [
                hiring.full_name.title(), formatted_interview_date, hiring.interview_time,
                location.title(), hiring.applied_from_company.title()
            ]

        if status == 'interview done':
            hiring.reason = request.POST.get('reason') or None

        elif status == 'selected':
            hiring.joining_date = request.POST.get('joining_date') or None
            hiring.reason = None

            head = request.POST.get('head') or None

            template_name = 'selection_message'

            try:
                formatted_joining_date = datetime.strptime(hiring.joining_date, "%Y-%m-%d").strftime("%d-%m-%Y")
            except (ValueError, TypeError):
                formatted_joining_date = "To be announced"

            template_params = [
                hiring.full_name.title(), formatted_joining_date, location.title(), hiring.applied_from_company.title()
            ]

            full_name_parts = hiring.full_name.split()
            first_name = full_name_parts[0] if len(full_name_parts) > 0 else ''
            middle_name = full_name_parts[1] if len(full_name_parts) > 2 else ''
            last_name = full_name_parts[-1] if len(full_name_parts) > 1 else ''

            if hiring.applying_for == "employee":
                employee = tbl_employee.objects.create(
                    name=first_name,
                    middle_name=middle_name,
                    last_name=last_name,
                    ph_no=hiring.mobile,
                    email=hiring.email,
                    join_date=hiring.joining_date,
                    employee_id_custom=generate_employee_id(),
                    is_active=True,
                    create_time=timezone.now() + timedelta(hours=5, minutes=30),
                    role_id =3,
                    role_name ="Software Developer",
                    head_id = head,
                )

                user = tbl_users2.objects.create(
                    name=first_name,
                    middle_name=middle_name,
                    last_name=last_name,
                    mobile=hiring.mobile,
                    email=hiring.email,
                    emp_id=employee.emp_id,
                    is_active=True,
                    created_dtm=timezone.now() + timedelta(hours=5, minutes=30),
                    role_id =3,
                    role_name ="Software Developer",
                    head_id = head,
                )
                
                employee.user_id = user.userId
                employee.save()
                user.save()
                hiring.delete()
                return redirect('employee_list')      

            elif hiring.applying_for == "intern":
                intern = tbl_intern.objects.create(
                    name=first_name,
                    middle_name=middle_name,
                    last_name=last_name,
                    ph_no=hiring.mobile,
                    email=hiring.email,
                    emp_type="intern",
                    join_date=hiring.joining_date,
                    intern_id_custom=generate_intern_id(),
                    is_active=True,
                    create_time=timezone.now() + timedelta(hours=5, minutes=30),
                    role_id =13,
                    role_name ="intern",
                    head_id = head,
                )

                user = tbl_users2.objects.create(
                    name=first_name,
                    middle_name=middle_name,
                    last_name=last_name,
                    mobile=hiring.mobile,
                    email=hiring.email,
                    emp_type='intern',
                    intern_id=intern.emp_id,
                    is_active=True,
                    created_dtm=timezone.now() + timedelta(hours=5, minutes=30),
                    role_id =13,
                    role_name ="intern",
                    head_id = head,
                )
                intern.user_id = user.userId
                intern.save()
                user.save()
                hiring.delete()
                return redirect('intern_list')        

        elif status in ['rejected', 'on-hold']:
            hiring.reason = request.POST.get('reason') or None
            hiring.joining_date = None

        hiring.save()

        if hiring.mobile and template_name:
            send_whatsapp_message(
                hiring.mobile,
                message_type='template',
                template_name=template_name,
                template_params=template_params
            )

        messages.success(request, 'Status updated and WhatsApp message sent.')
        return redirect('hiring_list')

def send_tomorrow_meeting_reminders(request):
    tomorrow = datetime.now().date() + timedelta(days=1)

    leads = tbl_lead.objects.filter(
        next_meeting_date__date=tomorrow,
        status="Meeting"
    )
    if leads:
        sent_count = 0
        for curr_data in leads:
            ph_no = str(curr_data.mobile).strip()
            company_obj = get_object_or_404(master_company, com_id=curr_data.company_id)
            company_name = company_obj.com_name.title()
            lead_name = curr_data.c_name.title()
            meeting_date_str = curr_data.next_meeting_date.strftime('%d-%m-%Y | %I:%M %p')
    
            send_whatsapp_message(
                ph_no,
                message_type='template',
                template_name='meeting_message_2',
                template_params=[company_name, lead_name, meeting_date_str]
            )
            sent_count += 1
    
        return JsonResponse({'success': True, 'message': f'Meeting reminders sent to {sent_count} leads.'})
    else:
        return JsonResponse({'success': False, 'message': 'No Meetings Tomorrow.'})

def parse_duration(duration):
    months = 0
    days = 0

    months_pattern = re.compile(r'(\d+(\.\d+)?)\s*(months?|mo)')
    days_pattern = re.compile(r'(\d+(\.\d+)?)\s*days?')
    years_pattern = re.compile(r'(\d+(\.\d+)?)\s*years?')

    duration = duration.lower()

    years_match = years_pattern.search(duration)
    if years_match:
        years = float(years_match.group(1))
        months += int(years * 12)

    months_match = months_pattern.search(duration)
    if months_match:
        months += int(float(months_match.group(1)))
        
    days_match = days_pattern.search(duration)
    if days_match:
        days += int(float(days_match.group(1)))

    return months, days

# @api_view(['POST'])
# def client_purchase(request):
#     try:
#         if request.method == 'POST': 
#             client_id = request.data.get('userId')
#             plan_id = request.data.get('planId')
#             plan_amount = request.data.get('price')
#             discount = request.data.get('discount')
#             final_amount = request.data.get('final_price')
#             promocode = request.data.get('promocode')
            
#             current_time = timezone.now() + timedelta(hours=5, minutes=30)
            
#             plan = tbl_plan.objects.get(id=plan_id)  # Assuming `tbl_plan` has a field `id`
#             duration = plan.duration  # Get the duration string (e.g., "3 Months", "1 Month", etc.)
            
#             # Parse the duration into months and days
#             months, days = parse_duration(duration)
            
#             # Get the current date and calculate start and end dates
#             current_time = timezone.now()
#             start_date = current_time  # Start date is the current time
            
#             # Calculate the end date based on the parsed duration
#             end_date = current_time + relativedelta(months=+months, days=+days) 
            
#             new = tbl_pure_client.objects.create(
#                 client_id = client_id,
#                 plan_id = plan_id,
#                 plan_amount = plan_amount,
#                 discount = discount,
#                 final_amount = final_amount,
#                 promocode = promocode,
#                 start_date = start_date,
#                 end_date = end_date,
#                 created_time = current_time
#             )
                
#             return Response({"success": f"Data added successfully!"}, status=status.HTTP_201_CREATED)
#     except Exception as e:
#         return Response({"error": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


@csrf_exempt
def initiate_payment(request):
    if request.method == "POST":
        try:
            data = json.loads(request.body)
            plan_id = data['planId']
            user_id = data['userId']
            price = data['price']
            discount = data['discount']
            final_price = data['final_price']
            promo_code = data['promocode']
            
            current_time = timezone.now() + timedelta(hours=5, minutes=30)
            
            plan = tbl_plan.objects.get(id=plan_id)
            duration = plan.duration
            
            months, days = parse_duration(duration)
            
            current_time = timezone.now() + timedelta(hours=5, minutes=30)
            start_date = current_time
            
            end_date = current_time + relativedelta(months=+months, days=+days)
            
            order_id = f"ORD{timezone.now().strftime('%Y%m%d%H%M%S')}"
            
            order = tbl_order.objects.create(
                plan_id=plan_id,
                user_id=user_id,
                price=price,
                discount=discount,
                final_price=final_price,
                promo_code=promo_code,
                start_date=start_date,
                end_date=end_date,
                created_time=current_time,
                order_id = order_id,
            )
            
            phonepe_data = {
                "merchantId": 'M22II6DDHVA4M',
                "merchantTransactionId": order_id,
                "merchantUserId": f'MUID{timezone.now().timestamp()}',
                "amount": final_price * 100,
                "redirectUrl": 'https://shubhamsingh.in/new_crm/payment_callback/',
                "redirectMode": "POST",
                "mobileNumber": 'user-phone',
                "OrderId": order_id,
                "paymentInstrument": {"type": "PAY_PAGE"}
            }
            
            json_payload = json.dumps(phonepe_data)
            encoded_payload = base64.b64encode(json_payload.encode('utf-8')).decode('utf-8')
            
            key = '2f58695e-7ce2-497f-b7aa-8fa217fd0eb2'
            key_index = 1
            string_to_hash = f"{encoded_payload}/pg/v1/pay{key}"
            sha256_hash = hashlib.sha256(string_to_hash.encode('utf-8')).hexdigest()
            final_x_header = f"{sha256_hash}###{key_index}"
            
            url = "https://api.phonepe.com/apis/hermes/pg/v1/pay"
            headers = {
                "Content-Type": "application/json",
                "accept": "application/json",
                "X-VERIFY": final_x_header,
            }
            
            request_data = {"request": encoded_payload}
            response = requests.post(url, json=request_data, headers=headers)
            response_data = response.json()
            
            if 'data' in response_data and 'instrumentResponse' in response_data['data']:
                redirect_url = response_data['data']['instrumentResponse']['redirectInfo']['url']
                return JsonResponse({'success': True, 'redirect_url': redirect_url}, status=200)
            else:
                return JsonResponse({'success': False, 'error': 'Payment initiation failed.'}, status=400)
        
        except Exception as e:
            return JsonResponse({'success': False, 'error': str(e)}, status=400) 
    
    return JsonResponse({'success': False, 'error': 'Invalid request method'}, status=405)
    
@csrf_exempt
def payment_callback(request):
    if request.method == "POST":
        try:
            # Step 1: Parse incoming data (handle both JSON and form-encoded)
            if request.content_type == 'application/json':
                response_data = json.loads(request.body)
            else:
                response_data = request.POST

            # Log or debug raw response
            print("PhonePe callback data:", response_data)

            # Step 2: Extract transaction info
            status = response_data.get('code', '')
            data = response_data.get('data', {}) if isinstance(response_data.get('data'), dict) else {}

            # Use fallback values if 'data' is missing
            order_id = data.get('merchantTransactionId') or response_data.get('transactionId')
            transaction_id = data.get('transactionId') or response_data.get('transactionId')
            reference_id = data.get('providerReferenceId') or response_data.get('providerReferenceId')

            if not order_id:
                return JsonResponse({'success': False, 'error': 'Missing order ID'}, status=400)

            payment_status = "success" if status == "PAYMENT_SUCCESS" else "failed"

            # Step 3: Update order
            order = tbl_order.objects.get(order_id=order_id)
            order.payment_status = payment_status
            order.phonepe_transaction_id = transaction_id
            order.phonepe_reference_id = reference_id
            order.save()

            # Step 4: Return response
            if payment_status == "success":
                return JsonResponse({'success': True, 'message': 'Payment successful'}, status=200)
            else:
                return JsonResponse({'success': False, 'message': 'Payment failed'}, status=400)

        except tbl_order.DoesNotExist:
            return JsonResponse({'success': False, 'error': 'Order not found'}, status=404)
        except Exception as e:
            return JsonResponse({'success': False, 'error': str(e)}, status=500)

    return JsonResponse({'success': False, 'error': 'Invalid request method'}, status=405)

# def verify_payment_status(order_id):
#     try:
#         # Ensure you're using the correct PhonePe credentials and endpoint
#         key = '2f58695e-7ce2-497f-b7aa-8fa217fd0eb2'  # Replace with your actual PhonePe key
#         key_index = 1
#         merchant_id = 'M22II6DDHVA4M'  # Your PhonePe Merchant ID
#         path = f"/apis/hermes/pg/v1/status/{merchant_id}/{order_id}"

#         # Create the hash to verify the request
#         string_to_hash = f"{path}{key}"
#         sha256_hash = hashlib.sha256(string_to_hash.encode()).hexdigest()
#         final_x_header = f"{sha256_hash}###{key_index}"

#         # Make the GET request to PhonePe status API
#         url = f"https://api.phonepe.com{path}"  # Verify the full URL with correct base URL
#         headers = {
#             "Content-Type": "application/json",
#             "X-VERIFY": final_x_header,
#         }

#         response = requests.get(url, headers=headers)
        
#         # Log the status response for debugging
#         print(f"PhonePe API Response: {response.text}")
        
#         return response.json()

#     except Exception as e:
#         # Handle any exceptions during the request
#         print(f"Error in verifying payment status: {e}")
#         return {"error": str(e)}

 

# @csrf_exempt
# def payment_callback(request):
#     if request.method == "POST":
#         try:
#             # Step 1: Parse incoming data (supports both JSON and form POST)
#             if request.content_type == 'application/json':
#                 response_data = json.loads(request.body)
#             else:
#                 response_data = request.POST

#             # Step 2: Debug logs to inspect raw data
#             print("=== PhonePe Callback ===")
#             print("Content Type:", request.content_type)
#             print("Request Headers:", dict(request.headers))
#             print("Raw Body:", request.body)
#             print("Parsed Data:", response_data)

#             # Step 3: Extract order ID from possible keys
#             order_id = (
#                 response_data.get("merchantTransactionId") or
#                 response_data.get("merchantOrderId") or
#                 response_data.get("orderId")
#             )

#             print("Resolved Order ID:", order_id)

#             if not order_id:
#                 return JsonResponse({'success': False, 'error': 'Missing order ID'}, status=400)

#             # Step 4: Extract other fields
#             transaction_id = response_data.get('transactionId')
#             reference_id = response_data.get('providerReferenceId')
#             checksum = response_data.get('checksum')  # Optional
#             amount = response_data.get('amount')

#             # Step 5: Verify payment status with PhonePe API
#             status_result = verify_payment_status(order_id)
#             print("PhonePe Status API Response:", status_result)

#             status_code = status_result.get("data", {}).get("responseCode")

#             # Step 6: Determine status
#             if status_code == "PAYMENT_SUCCESS":
#                 payment_status = "success"
#             else:
#                 payment_status = "failed"

#             # Step 7: Update order in database
#             try:
#                 order = tbl_order.objects.get(order_id=order_id)
#             except tbl_order.DoesNotExist:
#                 return JsonResponse({'success': False, 'error': 'Order not found'}, status=404)

#             order.payment_status = payment_status
#             order.phonepe_transaction_id = transaction_id
#             order.phonepe_reference_id = reference_id
#             order.save()

#             # Step 8: Return final result
#             if payment_status == "success":
#                 return JsonResponse({'success': True, 'message': 'Payment successful'}, status=200)
#             else:
#                 return JsonResponse({'success': False, 'message': 'Payment failed'}, status=400)

#         except Exception as e:
#             print("Exception in callback:", str(e))
#             return JsonResponse({'success': False, 'error': str(e)}, status=500)

#     return JsonResponse({'success': False, 'error': 'Invalid request method'}, status=405)


# @csrf_exempt
# def toggle_active_user(request, user_id):
#     if request.method == 'POST':
#         try:
#             user = tbl_users2.objects.get(userId=user_id)
#             user.is_active = not user.is_active
#             user.save()
#             return JsonResponse({'success': True, 'is_active': user.is_active})
#         except User.DoesNotExist:
#             return JsonResponse({'success': False, 'error': 'User not found'})
#     return JsonResponse({'success': False, 'error': 'Invalid request method'})

@csrf_exempt
def toggle_active_user(request, user_id):
    if request.method == 'POST':
        try:
            try :
                employee = tbl_employee.objects.get(user_id=user_id)
                employee.is_active = not employee.is_active
                employee.deactivation_date=timezone.now()
                employee.save()
            except:
                intern = tbl_intern.objects.get(user_id=user_id)
                intern.is_active = not intern.is_active
                intern.deactivation_date=timezone.now()
                intern.save()
            finally:
                user = tbl_users2.objects.get(userId=user_id)
                user.is_active = not user.is_active
                user.deactivation_date=timezone.now()
                user.save()
            return JsonResponse({'success': True, 'is_active': user.is_active})
        except tbl_users2.DoesNotExist:
            return JsonResponse({'success': False, 'error': 'User not found'}, status=404)
        except Exception as e:
            import traceback
            print("ERROR TOGGLING USER:\n", traceback.format_exc())
            return JsonResponse({'success': False, 'error': str(e)}, status=500)
    return JsonResponse({'success': False, 'error': 'Invalid method'}, status=405)
    


# manage interns

def add_intern(request):
    if 'session_id' in request.session:
        Username = request.session['session_user']
        company_id = request.session['company_id']
        session_roleid = request.session.get('session_roleid')
        cites = master_city.objects.all()  
        state = master_state.objects.all()  
        products = master_product.objects.all()
        # shift = master_shift.objects.all()
        allleadtype = master_leadtype.objects.all() 
        user_compeny = request.session['user_compney']  
        roles = tbl_roles.objects.all()[1:]  # Skipping the first role
        users = tbl_users2.objects.all()
        compney_list = master_company.objects.all()
        # selected_company_id = request.session.get('selected_company_id', None)
        # selected_company_name = master_company.objects.get(com_id=selected_company_id)
        shifts_raw = master_shift.objects.all()
        shifts = []
    
        for shift in shifts_raw:
            start = shift.start_time.strftime('%H:%M')
            end = shift.end_time.strftime('%H:%M')
            time_range = f"{start} - {end}"
            shifts.append({
                'time_range': time_range,
                'shift_name': shift.shift  # optional: add shift name if needed
            })

        return render(request, "intern-form.html", {'compney_list':compney_list,'state':state,'roles':roles,'users':users,'shifts':shifts,'cites': cites, 'products': products, 'Username':Username, 'allleadtype':allleadtype, 'companey_list':master_company.objects.all(),'comp_name':user_compeny, 'session_roleid':session_roleid,'company_id': company_id}) 
        # return render(request, "intern-onboarding-leasting.html", {'selected_company_id':selected_company_id,'selected_company_name':selected_company_name, 'compney_list':compney_list,'state':state,'roles':roles,'users':users,'shift':shift,'cites': cites, 'products': products, 'Username':Username, 'allleadtype':allleadtype, 'companey_list':master_company.objects.all(),'comp_name':user_compeny, 'session_roleid':session_roleid,'company_id': company_id}) 
   
    else:
        return redirect(login)

def add_intern_onboarding(request):
    if 'session_id' not in request.session:
        return redirect('login')

    session_id = request.session.get('session_id')
    session_roleid = request.session.get('session_roleid')
    # company_id = request.session.get('company_id')
    session_user = request.session.get('session_user')
    selected_company_id = request.session.get('selected_company_id', None)

    def parse_date(date_str):
        return datetime.strptime(date_str, '%Y-%m-%d') if date_str else None

    def get_uploaded_file(field_name, request, default=None):
        file = ""
        try:
            file = request.FILES[field_name]
        except:
            file = ""
        finally:
            return file

    if request.method == 'POST':
        # File Uploads (safely handled)
        aadhar_pdf = get_uploaded_file('aadhar_data', request)
        pan_pdf = get_uploaded_file('pan_data', request)
        photo = get_uploaded_file('photo_data', request)
        joining_letter = get_uploaded_file('joining_letter', request)
        bank_statement = get_uploaded_file('bank_statement', request)

        # Personal Info
        name = request.POST.get('name', '')
        middle_name = request.POST.get('middle_name', '')
        last_name = request.POST.get('last_name', '')
        date_of_birth = parse_date(request.POST.get('date_of_birth'))
        gender = request.POST.get('gender', '')
        marital_status = request.POST.get('marital_status', '')
        machine_id = request.POST.get('machine_id') or None
        ph_no = request.POST.get('ph_no', '')
        email = request.POST.get('email', '')
        emer_cont_pers = request.POST.get('emer_cont_pers', '')
        emer_cont_ph_no = request.POST.get('emer_cont_ph_no', '')
        address = request.POST.get('address', '')
        city = request.POST.get('city', '')
        state = request.POST.get('state', '')
        country = request.POST.get('country', '')
        zip_code = request.POST.get('zip_code', '')
        college_name = request.POST.get('college_name', '')
        college_id = request.POST.get('college_id', '')
        enrollment_no = request.POST.get('enrollment_no', '')

        # Other Info
        emp_type = request.POST.get('emp_type', '')
        attendence_time = request.POST.get('attendence_time', '')
        gross_sal = request.POST.get('gross_sal', '')
        intern_id_custom = generate_intern_id()
        password = request.POST.get('password', '')
        head_id = request.POST.get('head') or None
        join_date = parse_date(request.POST.get('join_date'))
        completion_date = parse_date(request.POST.get('completion_date'))
        company_name = request.POST.get('company_name', '')
        company_obj = master_company.objects.filter(com_name=company_name).first()
        company_id = company_obj.com_id if company_obj else None

        # IDs
        role_ids = request.POST.getlist('roles')
        depart_ids = request.POST.getlist('departments')

        # Role name fetch
        role_names = [r.role for r in tbl_roles.objects.filter(roleId__in=role_ids)]
        role_name = ', '.join(role_names)

        # Bank Info
        stipend = request.POST.get('stipend', '')
        acc_num = request.POST.get('acc_num', '')
        acc_holder_name = request.POST.get('acc_holder_name', '')
        bank_name = request.POST.get('bank_name', '')
        ifsc_code = request.POST.get('ifsc_code', '')
        branch_add = request.POST.get('branch_add', '')

        # Benefits
        med_benifit = request.POST.get('med_benifit', '')
        family_benifit = request.POST.get('family_benifit', '')
        transport_benifit = request.POST.get('transport_benifit', '')
        other_benifit = request.POST.get('other_benifit', '')

        # Create intern record dictionary
        intern_data = {
            'name': name,
            'middle_name': middle_name,
            'last_name': last_name,
            'date_of_birth': date_of_birth,
            'gender': gender,
            'marital_status': marital_status,
            'machine_id': machine_id,
            'ph_no': ph_no,
            'email': email,
            'emer_cont_pers': emer_cont_pers,
            'emer_cont_ph_no': emer_cont_ph_no,
            'address': address,
            'city': city,
            'state': state,
            'country': country,
            'zip_code': zip_code,
            'attendence_time': attendence_time,
            'gross_sal': gross_sal,
            'intern_id_custom': intern_id_custom,
            'password': password,
            'head_id': head_id,
            'join_date': join_date,
            'completion_date': completion_date,
            'company_id': company_id,
            'company_name': company_name,
            'dp_id': ','.join(depart_ids),
            'role_id': ','.join(role_ids),
            'role_name': role_name,
            'emp_type': emp_type,
            'stipend': stipend,
            'college_name': college_name,
            'college_id': college_id,
            'enrollment_no': enrollment_no,
            'acc_num': acc_num,
            'acc_holder_name': acc_holder_name,
            'bank_name': bank_name,
            'ifsc_code': ifsc_code,
            'branch_add': branch_add,
            'med_benifit': med_benifit,
            'family_benifit': family_benifit,
            'transport_benifit': transport_benifit,
            'other_benifit': other_benifit,
            'add_by_id': session_id,
            'add_by_name': session_user,
            'update_by_id': session_id,
            'update_by_name': session_user,
            'create_time': timezone.now() + timedelta(hours=5, minutes=30),
        }

        # Attach files if uploaded
        if aadhar_pdf:
            intern_data['aadhar_pdf'] = aadhar_pdf
        if pan_pdf:
            intern_data['pan_pdf'] = pan_pdf
        if photo:
            intern_data['photo'] = photo
        if joining_letter:
            intern_data['joining_letter'] = joining_letter
        if bank_statement:
            intern_data['bank_statement'] = bank_statement

        # Save intern
        new_lead = tbl_intern.objects.create(**intern_data)

        # Save user account
        new_user = tbl_users2.objects.create(
            emp_type =emp_type,
            intern_id=new_lead.emp_id,
            name=name,
            middle_name=middle_name,
            last_name=last_name,
            mobile=ph_no,
            email=email,
            created_dtm=timezone.now() + timedelta(hours=5, minutes=30),
            password=password,
            company_name=company_name,
            company_id=company_id,
            role_name=role_name,
            head_id=head_id,
            add_by_name=session_user,
            add_by_id=session_id,
            status='Active',
            role_id=','.join(role_ids),
            dp_id=','.join(depart_ids),
            updated_by_id=session_id,
        )
        
        if photo:
            new_user.photo = photo

        new_user.save()
        new_lead.user_id = new_user.userId
        new_lead.save()

        # Log entry
        ip_address = get_client_ip(request)
        tbl_messages.objects.create(
            message_name=session_user,
            change_status=f"Add intern On Boarding - {name}",
            added_date=timezone.now() + timedelta(hours=5, minutes=30),
            company_id=company_id,
            user_id = request.session['session_id'],
            ip_address = ip_address,
        )

        return JsonResponse({'status': 'success', 'message': f'intern {name} added successfully!'})

    return render(request, "intern-onboarding-leasting.html", {'session_roleid': session_roleid})

def intern_list(request):
    if 'session_id' in request.session:
        session_roleid = request.session.get('session_roleid')
        
        # if set(session_roleid).intersection({"1"}):
        selected_company_id = request.session.get('selected_company_id', None)
        if selected_company_id:
            employee = tbl_intern.objects.filter(company_id=selected_company_id) 
        else:
            employee = tbl_intern.objects.all()
        # else:
        #     employee = tbl_intern.objects.all()
            
        # employee = tbl_intern.objects.all()
        # shifts = master_shift.objects.all()
        
        # from_date = request.GET.get('fromDate')
        # to_date = request.GET.get('toDate')
        emp_id = request.GET.get('emp_id')
        name = request.GET.get('name')
        email = request.GET.get('email')
        ph_no = request.GET.get('ph_no')
        # alt_ph_no = request.GET.get('alt_ph_no')
        address = request.GET.get('address')
        shift = request.GET.get('shift')
        # emp_type = request.GET.get('emp_type')
        join_date = request.GET.get('join_date')
        date_of_birth = request.GET.get('date_of_birth')
        # anniversary_date = request.GET.get('anniversary_date')
        # aadhar_number = request.GET.get('aadhar_number')
        # bank_name = request.GET.get('bank_name')
        # acc_num = request.GET.get('acc_num')
        # ifsc_code = request.GET.get('ifsc_code')
        
        # query = Q()
            
        date_range_filter = request.GET.get('fromDate')  # or request.POST if it's a POST form
        
        if date_range_filter:
            try:
                start_str, end_str = date_range_filter.split(' - ')
                start_date = parser.parse(start_str.strip())
                end_date = parser.parse(end_str.strip()).replace(hour=23, minute=59, second=59, microsecond=999999)
                employee = employee.filter(create_time__gte=start_date, create_time__lte=end_date)
            except Exception as e:
                print(f"Date parsing error: {e}")
            
        if emp_id:
            employee = employee.filter(intern_id_custom__icontains=emp_id)
        if name:
            # employee = employee.filter(name__icontains=name)
            employee = employee.filter(Q(name__icontains=name) | Q(middle_name__icontains=name) | Q(last_name__icontains=name))
        if email:
            employee = employee.filter(email__icontains=email)
        if ph_no:
            employee = employee.filter(ph_no__icontains=ph_no)
        # if alt_ph_no:
        #     employee = employee.filter(alt_ph_no__icontains=alt_ph_no)
        if address:
            employee = employee.filter(address__icontains=address)
        # if shift:
        #     employee = employee.filter(attendence_time__icontains=shift)
        # if emp_type:
        #     employee = employee.filter(emp_type__icontains=emp_type)
        if join_date:
            employee = employee.filter(join_date__icontains=join_date)
        if date_of_birth:
            employee = employee.filter(date_of_birth__icontains=date_of_birth)
        # if anniversary_date:
        #     employee = employee.filter(anniversary_date__icontains=anniversary_date)
        # if aadhar_number:
        #     employee = employee.filter(aadhar_number__icontains=aadhar_number)
        # if bank_name:
        #     employee = employee.filter(bank_name__icontains=bank_name)
        # if acc_num:
        #     employee = employee.filter(acc_num__icontains=acc_num)
        # if ifsc_code:
        #     employee = employee.filter(ifsc_code__icontains=ifsc_code)

        # employee = employee.filter(query) 
        employee = employee.order_by('-is_active','-emp_id')
        
         
        active_user = 0
        inactive_user = 0
        all_user = employee.count()
        for i in employee:
            if i.is_active:
                active_user += 1
            if not i.is_active:
                inactive_user += 1
        
        return render(request,"intern-list.html",{
            # 'shifts':shifts,
            'intern':employee,
            'session_roleid':session_roleid,
            'all_user':all_user,
            'inactive_user':inactive_user,
            'active_user':active_user,
        })
        
    else:
        return redirect(login)

def intern_excel(request):
    if 'session_id' in request.session:
        session_roleid = request.session.get('session_roleid')
        selected_company_id = request.session.get('selected_company_id')

        if request.method == 'POST':
            date_range = request.POST.get('fromDate')

            if date_range:
                try:
                    date_range = date_range.replace('+', ' ')
                    start_str, end_str = date_range.split(' - ')
                    from_date = parser.parse(start_str.strip()).replace(hour=0, minute=0, second=0)
                    to_date = parser.parse(end_str.strip()).replace(hour=23, minute=59, second=59)
                    if from_date > to_date:
                        from_date, to_date = to_date, from_date
                except ValueError:
                    return HttpResponse("Invalid date range.", status=400)

            intern_entries = tbl_intern.objects.filter(create_time__range=[from_date, to_date])
            
            if selected_company_id:
                intern_entries = intern_entries.filter(company_id=selected_company_id)

            if intern_entries.count() == 0:
                return HttpResponse("No intern records found for the given date range.", status=404)

            wb = Workbook()
            ws = wb.active
            ws.title = "Intern Report"

            headers = [
                "Intern ID", "User ID", "Name", "Middle Name", "Last Name", "Date of Birth", "Gender",
                "Marital Status", "Machine ID", "Phone Number", "Email", "Emergency Contact Person",
                "Emergency Contact Number", "Address", "City", "State", "Country", "Zip Code",
                "Employee Type", "Attendance Time", "Gross Salary", "College Name", "Custom Intern ID",
                "Password", "Head ID", "Joining Date", "Completion Date", "Company ID", "Company Name",
                "Department ID", "Role ID", "Role Name", "Stipend", "Account Number", "Account Holder Name",
                "Bank Name", "IFSC Code", "Branch Address", "Medical Benefit", "Family Benefit",
                "Transport Benefit", "Other Benefit", "Added By ID", "Added By Name", "Updated By ID",
                "Updated By Name", "Created Time", "Is Active"
            ]

            ws.append(headers)

            for entry in intern_entries:
                ws.append([
                    entry.emp_id,
                    entry.user_id,
                    entry.name,
                    entry.middle_name,
                    entry.last_name,
                    entry.date_of_birth.strftime('%d/%m/%Y') if entry.date_of_birth else '',
                    entry.gender,
                    entry.marital_status,
                    entry.machine_id,
                    entry.ph_no,
                    entry.email,
                    entry.emer_cont_pers,
                    entry.emer_cont_ph_no,
                    entry.address,
                    entry.city,
                    entry.state,
                    entry.country,
                    entry.zip_code,
                    entry.emp_type,
                    entry.attendence_time,
                    entry.gross_sal,
                    entry.college_name,
                    entry.intern_id_custom,
                    entry.password,
                    entry.head_id,
                    entry.join_date.strftime('%d/%m/%Y') if entry.join_date else '',
                    entry.completion_date.strftime('%d/%m/%Y') if entry.completion_date else '',
                    entry.company_id,
                    entry.company_name,
                    entry.dp_id,
                    entry.role_id,
                    entry.role_name,
                    entry.stipend,
                    entry.acc_num,
                    entry.acc_holder_name,
                    entry.bank_name,
                    entry.ifsc_code,
                    entry.branch_add,
                    entry.med_benifit,
                    entry.family_benifit,
                    entry.transport_benifit,
                    entry.other_benifit,
                    entry.add_by_id,
                    entry.add_by_name,
                    entry.update_by_id,
                    entry.update_by_name,
                    entry.create_time.strftime('%d/%m/%Y %H:%M') if entry.create_time else '',
                    "Yes" if entry.is_active else "No"
                ])

            response = HttpResponse(content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
            response['Content-Disposition'] = 'attachment; filename="Intern-Report.xlsx"'
            wb.save(response)
            return response

        return render(request, "intern-list.html", {'session_roleid': session_roleid})
    else:
        return redirect('login')

def edit_intern(request, intern_id):
    if 'session_id' not in request.session:
        return redirect('login')

    intern = get_object_or_404(tbl_intern, emp_id=intern_id)

    def parse_date(date_str):
        return datetime.strptime(date_str, '%Y-%m-%d') if date_str else None

    def get_uploaded_file(field_name, request, default=None):
        file = ""
        try:
            file = request.FILES[field_name]
        except:
            file = ""
        finally:
            return file

    if request.method == 'POST':
        try:
            # File uploads
            aadhar_pdf = get_uploaded_file('aadhar_data', request)
            pan_pdf = get_uploaded_file('pan_data', request)
            photo = get_uploaded_file('photo_data', request)
            joining_letter = get_uploaded_file('joining_letter', request)
            bank_statement = get_uploaded_file('bank_statement', request)

            # Personal Info
            intern.name = request.POST.get('name', '')
            intern.middle_name = request.POST.get('middle_name', '')
            intern.last_name = request.POST.get('last_name', '')
            intern.date_of_birth = parse_date(request.POST.get('date_of_birth'))
            intern.gender = request.POST.get('gender', '')
            intern.marital_status = request.POST.get('marital_status', '')
            intern.machine_id = request.POST.get('machine_id') or None
            intern.ph_no = request.POST.get('ph_no', '')
            intern.email = request.POST.get('email', '')
            intern.emer_cont_pers = request.POST.get('emer_cont_pers', '')
            intern.emer_cont_ph_no = request.POST.get('emer_cont_ph_no', '')
            intern.address = request.POST.get('address', '')
            intern.city = request.POST.get('city', '')
            intern.state = request.POST.get('state', '')
            intern.country = request.POST.get('country', '')
            intern.zip_code = request.POST.get('zip_code', '')
            intern.college_name = request.POST.get('college_name', '')
            intern.college_id = request.POST.get('college_id', '')
            intern.enrollment_no = request.POST.get('enrollment_no', '')

            # Other Info
            intern.attendence_time = request.POST.get('attendence_time', '')
            intern.gross_sal = request.POST.get('gross_sal', '')
            intern.password = request.POST.get('password', '')
            intern.head_id = request.POST.get('head') or None
            intern.join_date = parse_date(request.POST.get('join_date'))
            intern.completion_date = parse_date(request.POST.get('completion_date'))
            intern.company_name = request.POST.get('company_name', '')
            company_name = request.POST.get('company_name', '')
            company_obj = master_company.objects.filter(com_name=company_name).first()
            company_id = company_obj.com_id if company_obj else None
            intern.company_id = company_id
            # IDs
            role_ids = request.POST.getlist('roles')
            depart_ids = request.POST.getlist('departments')
            intern.role_id = ','.join(role_ids)
            intern.dp_id = ','.join(depart_ids)

            role_names = [r.role for r in tbl_roles.objects.filter(roleId__in=role_ids)]
            intern.role_name = ', '.join(role_names)

            # Bank Info
            intern.stipend = request.POST.get('stipend', '')
            intern.acc_num = request.POST.get('acc_num', '')
            intern.acc_holder_name = request.POST.get('acc_holder_name', '')
            intern.bank_name = request.POST.get('bank_name', '')
            intern.ifsc_code = request.POST.get('ifsc_code', '')
            intern.branch_add = request.POST.get('branch_add', '')

            # Benefits
            intern.med_benifit = request.POST.get('med_benifit', '')
            intern.family_benifit = request.POST.get('family_benifit', '')
            intern.transport_benifit = request.POST.get('transport_benifit', '')
            intern.other_benifit = request.POST.get('other_benifit', '')

            # File updates
            if aadhar_pdf:
                intern.aadhar_pdf = aadhar_pdf
            if pan_pdf:
                intern.pan_pdf = pan_pdf
            if photo:
                intern.photo = photo
            if joining_letter:
                intern.joining_letter = joining_letter
            if bank_statement:
                intern.bank_statement = bank_statement

            intern.update_by_id = request.session['session_id']
            intern.update_by_name = request.session['session_user']
            intern.save()

            # Update user
            user = tbl_users2.objects.get(intern_id=intern.emp_id)
            user.name = intern.name
            user.middle_name = intern.middle_name
            user.last_name = intern.last_name
            user.email = intern.email
            user.password = intern.password
            user.mobile = intern.ph_no
            user.company_name = intern.company_name
            user.company_id = intern.company_id
            user.role_name = intern.role_name
            user.head_id = intern.head_id
            user.role_id = intern.role_id
            user.dp_id = intern.dp_id
            user.updated_by_id = request.session['session_id']
            if photo:
                user.photo = photo
            user.save()

            # Log
            tbl_messages.objects.create(
                message_name=request.session['session_user'],
                change_status=f"Edit Intern On Boarding - {intern.name}",
                added_date=timezone.now() + timedelta(hours=5, minutes=30),
                company_id=request.session['company_id']
            )

            return JsonResponse({'status': 'success', 'message': f'Intern {intern.name} updated successfully!'})

        except Exception as e:
            return JsonResponse({'status': 'error', 'message': str(e)})
    shifts_raw = master_shift.objects.all()
    shifts = [] 

    for shift in shifts_raw:
        start = shift.start_time.strftime('%H:%M')
        end = shift.end_time.strftime('%H:%M')
        time_range = f"{start} - {end}"
        shifts.append({
            'time_range': time_range,
            'shift_name': shift.shift  # optional: add shift name if needed
        })

    roles = tbl_roles.objects.all()[1:]
    compney_list = master_company.objects.all()
    user_roles = intern.role_id.split(',') if intern.role_id else []
    user_departments = intern.dp_id.split(',') if intern.dp_id else []

    return render(request, "intern-form.html", {
        'lead': intern,
        'compney_list': compney_list,
        'clients': master_client.objects.all(),
        'products': master_product.objects.all(),
        'comp_name': request.session['user_compney'],
        'session_roleid': request.session.get('session_roleid'),
        'company_id': request.session['company_id'],
        'is_edit': True,
        'users': tbl_users2.objects.all(),
        'roles': roles,
        'user_roles': user_roles,
        'user_departments': user_departments,
        'shifts': shifts,
        'state': master_state.objects.all(),
        'cites': master_city.objects.all(),
    })
       
def delete_intern_onboarding(request, intern_id):
    if 'session_id' in request.session:
        intern = get_object_or_404(tbl_intern, emp_id=intern_id)
        
        ip_address = get_client_ip(request)
        tbl_messages.objects.create(
            message_name=request.session['session_user'],
            change_status=f"Delete Intern On Boarding - {intern.name}",
            added_date=timezone.now() + timedelta(hours=5, minutes=30),
            company_id=request.session['company_id'],
            user_id = request.session['session_id'],
            ip_address = ip_address,
        )

        user = tbl_users2.objects.filter(intern_id=intern.emp_id).first()
        if user:
            user.delete()

        intern.delete()

        return JsonResponse({'success': True, 'name': intern.name})
    else:
        return redirect('login')

def add_hiring(request):
    if 'session_id' in request.session:
        session_roleid = request.session.get('session_roleid')
        companies = master_company.objects.all().order_by("com_name")
        return render(request, 'add-applicant.html', {
            'session_roleid': session_roleid,
            'companies': companies,
        })
    else:
        return redirect(login)
      
def delete_hiring(request, id):
    if 'session_id' in request.session:
        applicant = get_object_or_404(tbl_hiring, hiring_id=id)
        name= applicant.full_name
        applicant.delete()
        return JsonResponse({'success': True, 'c_name': name})
    else:
        return redirect(login)
      

def intern_details(request,emp_id):
    if 'session_id' in request.session:
        session_roleid = request.session.get('session_roleid')
        data = get_object_or_404(tbl_intern, emp_id=emp_id)
        Head_name_obj = get_object_or_404(tbl_users2, userId=data.head_id) 
        Head_name = f"{Head_name_obj.name} {Head_name_obj.middle_name} {Head_name_obj.last_name}"

        details_context = request.session.get('details_context')

        if details_context:
            context = {**details_context, 'data': data, 'session_roleid': session_roleid}
            del request.session['details_context']
            return render(request, "intern_details.html", context)
        else:
            context = {
                'data': data,
                'session_roleid': session_roleid,
                'Head_name': Head_name,
            }
        return render(request, "intern_details.html", context)
    else:
        return redirect('login')

def details_count_intern(request):
    if 'session_id' in request.session:
        session_roleid = request.session.get('session_roleid')

        emp_id = request.POST.get('emp_id')
        # from_date = request.POST.get('from_date')
        # to_date = request.POST.get('to_date')
        date_range = request.POST.get('fromDate')  # New field name from updated form
        action = request.POST.get('action')
        from_date = to_date = None

        if date_range:
            try:
                # Force to string in case it's a datetime object already
                date_range_str = str(date_range)
                date_parts = date_range_str.split(" - ")
                from_date_str = str(date_parts[0].strip())
                to_date_str = str(date_parts[1].strip())

                from_date = datetime.strptime(from_date_str, "%m/%d/%Y %I:%M %p") 
                to_date = datetime.strptime(to_date_str, "%m/%d/%Y %I:%M %p")

            except Exception as e:
                return JsonResponse({'error': f'Date parse error: {str(e)}'}, status=400)

        if from_date and to_date:
            employee = get_object_or_404(tbl_intern, emp_id=emp_id)
            machine_id = employee.machine_id
            emp_shift = employee.attendence_time
            user_id = employee.user_id
            full_name = f"{employee.name} {employee.middle_name} {employee.last_name}"
            company_id = employee.company_id
            cmp_obj = master_company.objects.get(com_id = company_id)
            company_name = cmp_obj.com_name
            company_address = f"{cmp_obj.address}, {cmp_obj.area}, {cmp_obj.city}, {cmp_obj.state}, {cmp_obj.pincode}"
            
            
            tasks = tbl_task.objects.filter(
                assign_to=user_id,
                assign_date__date__range=[from_date, to_date]
            )

            total_task = tasks.count()
            complete_task = pending_task = revised_task = task_delay = 0

            for task in tasks:
                if task.status == "Complete":
                    complete_task += 1
                if task.status == "Pending":
                    pending_task += 1
                if task.status == "Revise":
                    revised_task += 1
                if task.delay_count and isinstance(task.delay_count, str):
                    match = re.search(r'\d+', task.delay_count)
                    if match:
                        task_delay += int(match.group())

            attendances = tbl_attendances.objects.filter(
                date__range=[from_date, to_date],
                machine_id=machine_id
            ).order_by('date')

            breaks = tbl_break.objects.filter(
                date__range=[from_date, to_date],
                machine_id=machine_id
            ).order_by('date')

            breaks_data = []
            
            # Define lunch break window
            lunch_start_window = datetime.strptime("12:58", "%H:%M").time()
            lunch_end_window = datetime.strptime("13:58", "%H:%M").time()
            total_month_breaks = 0
            
            for br in breaks:
                raw_punches = br.punches.split("\n")
                punch_times = [p.strip() for p in raw_punches if p.strip() and p.strip() != "0"]
                punch_count = len(punch_times)
                break_pairs = []
                total_break_minutes = 0
                lunch_break = None
                used_indices = set()
            
                if punch_count >= 1:
                    i = 0
                    while i < punch_count:
                        if i in used_indices:
                            i += 1
                            continue
            
                        start_str = punch_times[i]
                        try:
                            fmt = "%H:%M"
                            start_time = datetime.strptime(start_str, fmt)
                        except:
                            break_pairs.append({
                                "pair": f"{start_str} - (invalid start)",
                                "duration": "Invalid time"
                            })
                            used_indices.add(i)
                            i += 1
                            continue
            
                        matched = False
                        for j in range(i + 1, punch_count):
                            if j in used_indices:
                                continue
                            end_str = punch_times[j]
                            try:
                                end_time = datetime.strptime(end_str, fmt)
                                if start_time < end_time <= start_time + timedelta(hours=1):
                                    duration = (end_time - start_time).seconds // 60
                                    start_t = start_time.time()
                                    end_t = end_time.time()
            
                                    is_lunch = (
                                        lunch_start_window <= start_t <= lunch_end_window or
                                        lunch_start_window <= end_t <= lunch_end_window
                                    )
            
                                    if is_lunch and not lunch_break:
                                        lunch_break = {
                                            "pair": f"{start_str} - {end_str}",
                                            "duration": f"{duration} mins"
                                        }
                                    else:
                                        total_break_minutes += duration
                                        break_pairs.append({
                                            "pair": f"{start_str} - {end_str}",
                                            "duration": f"{duration} mins"
                                        })
                                    used_indices.update([i, j])
                                    matched = True
                                    break
                            except:
                                continue
            
                        if not matched:
                            start_t = start_time.time()
                            is_lunch = lunch_start_window <= start_t <= lunch_end_window
            
                            if is_lunch and not lunch_break:
                                lunch_break = {
                                    "pair": f"{start_str} - (no end)",
                                    "duration": "Incomplete"
                                }
                            else:
                                break_pairs.append({
                                    "pair": f"{start_str} - (no end)",
                                    "duration": "Incomplete"
                                })
            
                            used_indices.add(i)
            
                        i += 1
            
                    total_month_breaks += total_break_minutes
            
                    # Format total break duration
                    hours = total_break_minutes // 60
                    minutes = total_break_minutes % 60
                    total_break_str = f"{hours}h {minutes}m" if hours else f"{minutes}m"
            
                else:
                    break_pairs.append({
                        "pair": "No Breaks",
                        "duration": ""
                    })
                    punch_count = 0
                    total_break_str = "0m"
            
                formatted_date = br.date.strftime("%d-%m-%Y") if br.date else "N/A"
            
                breaks_data.append({
                    'date': formatted_date,
                    'punch_count': punch_count,
                    'breaks': break_pairs,
                    'lunch_break': lunch_break,
                    'total_break_duration': total_break_str
                })
            
            # Final total_month_breaks formatting (outside the loop)
            month_hours = total_month_breaks // 60
            month_minutes = total_month_breaks % 60
            total_month_breaks_str = f"{month_hours}hr {month_minutes}m" if month_hours else f"{month_minutes}minutes"

            full_days = half_days = late_punches = early_punches = 0.0
            sunday_attendances = leave_days = rejected_double_leave_days = rejected_double_half_days = overtime_minutes = unapplied_half_days = unapplied_leaves = 0.0

            unique_dates = set()
            attendance_data = []
            prev_attendance = next_attendance = None

            leave_map = {}
            leave_type_map = {}
            exception_leave_dates = set()
            
            leave_apps = tbl_leave_appli.objects.filter(
                emp_id=user_id,
                app_start_date__lte=to_date,
                app_end_date__gte=from_date
            )
            
            # Get holidays between the date range
            holiday_qs = tbl_holiday.objects.filter(
                start_date__lte=to_date,
                to_date__gte=from_date
            )
            
            holiday_dates = set()
            for holiday in holiday_qs:
                current = holiday.start_date
                while current <= holiday.to_date:
                    holiday_dates.add(current.strftime("%Y-%m-%d"))
                    current += timedelta(days=1)
            
            holiday_count = len(holiday_dates)
            
            # for leave in leave_apps:
            #     current = leave.app_start_date
            #     while current <= leave.app_end_date:
            #         date_str = current.strftime("%Y-%m-%d")
            #         leave_map[date_str] = leave.status
            #         leave_type_map[date_str] = leave.leave_type
            #         current += timedelta(days=1)
            
            for leave in leave_apps:
                current = leave.app_start_date.date()
                while current <= leave.app_end_date.date():
                    date_str = current.strftime("%Y-%m-%d")
                    
                    # Exclude "Exception" leave type with "Approved" status
                    if leave.leave_type == "Exception" and leave.status == "Approved":
                        exception_leave_dates.add(date_str)
                    else:
                        leave_map[date_str] = leave.status
                        leave_type_map[date_str] = leave.leave_type
                    current += timedelta(days=1)
                    
            total_month_work_minutes = 0
            
            # from_date_dt = datetime.strptime(from_date, "%Y-%m-%d")
            # to_date_dt = datetime.strptime(to_date, "%Y-%m-%d")
            
            if isinstance(from_date, str):
                from_date_dt = datetime.strptime(from_date, "%Y-%m-%d")
            else:
                from_date_dt = from_date
            
            if isinstance(to_date, str):
                to_date_dt = datetime.strptime(to_date, "%Y-%m-%d")
            else:
                to_date_dt = to_date

            second_fourth_saturdays = get_second_and_fourth_saturdays(from_date_dt, to_date_dt)

            for i, attendance in enumerate(attendances):
                attendance_date_str = attendance.date.strftime("%Y-%m-%d")
                
                if attendance_date_str in holiday_dates:
                    attendance_data.append({
                        'date': datetime.strptime(attendance_date_str, "%Y-%m-%d").strftime("%d-%m-%Y"),
                        'punch_in': attendance.punch_in,
                        'punch_out': attendance.punch_out,
                        'worked_hours': "Holiday"
                    })
                    continue  # Skip holidays for any full/half/leave counts
                
                if attendance_date_str in exception_leave_dates:
                    prev_attendance = attendance
                    continue
                
                punch_in_time = None
                punch_out_time = None
                worked_duration = ""
                
                if attendance.punch_in and attendance.punch_out and attendance.punch_in != '0' and attendance.punch_out != '0':
                    try:
                        punch_in_time = datetime.strptime(attendance.punch_in, "%H:%M")
                        punch_out_time = datetime.strptime(attendance.punch_out, "%H:%M")
                        worked_minutes = (punch_out_time - punch_in_time).seconds // 60
                        worked_hours = worked_minutes // 60
                        worked_remaining_minutes = worked_minutes % 60
                        worked_duration = f"{worked_hours}h {worked_remaining_minutes}m"
                
                        total_month_work_minutes += worked_minutes  # ðŸ‘ˆ Add this line
                
                    except ValueError:
                        worked_duration = "Invalid time"
                elif (attendance.punch_in and attendance.punch_in != '0') or (attendance.punch_out and attendance.punch_out != '0'):
                    worked_duration = "Incomplete"
                else:
                    worked_duration = "Absent"
            
                attendance_data.append({
                    'date': datetime.strptime(attendance_date_str, "%Y-%m-%d").strftime("%d-%m-%Y"),
                    'punch_in': attendance.punch_in,
                    'punch_out': attendance.punch_out,
                    'worked_hours': worked_duration
                })

                next_attendance = attendances[i + 1] if i + 1 < len(attendances) else None

                if attendance.date.weekday() == 6:  # Sunday
                    sunday_attendances += 1.0
                    if prev_attendance and next_attendance:
                        if all([
                            not prev_attendance.punch_in or prev_attendance.punch_in == '0',
                            not prev_attendance.punch_out or prev_attendance.punch_out == '0',
                            not next_attendance.punch_in or next_attendance.punch_in == '0',
                            not next_attendance.punch_out or next_attendance.punch_out == '0'
                        ]):
                            leave_days += 1.0
                            sunday_attendances -= 1.0
                    continue

                leave_status = leave_map.get(attendance_date_str)
                leave_type = leave_type_map.get(attendance_date_str)

                # âœ… Add any punch-in or punch-out day to total_days_worked
                if (attendance.punch_in and attendance.punch_in != '0') or (attendance.punch_out and attendance.punch_out != '0'):
                    unique_dates.add(attendance_date_str)

                if leave_status == 'Approved':
                    leave_days += 1.0
                    prev_attendance = attendance
                    continue

                if leave_status == 'Rejected' and leave_type in ['Full Leave', 'Half Leave']:
                    if (not attendance.punch_in or attendance.punch_in == '0') and (not attendance.punch_out or attendance.punch_out == '0'):
                        leave_days += 1.0
                        rejected_double_leave_days += 1.0
                        prev_attendance = attendance
                        continue
                    if (not attendance.punch_in or attendance.punch_in == '0') or (not attendance.punch_out or attendance.punch_out == '0'):
                        rejected_double_half_days += 1
                        prev_attendance = attendance
                        continue

                # Check for unapplied full leave
                if attendance_date_str not in leave_map and attendance_date_str not in holiday_dates and attendance_date_str not in exception_leave_dates and attendance.date.weekday() != 6 and attendance_date_str not in second_fourth_saturdays:
                    if (not attendance.punch_in or attendance.punch_in == '0') and (not attendance.punch_out or attendance.punch_out == '0'):
                        unapplied_leaves += 1.0
                    elif (not attendance.punch_in or attendance.punch_in == '0') or (not attendance.punch_out or attendance.punch_out == '0'):
                        unapplied_half_days += 1.0

                if (not attendance.punch_in or attendance.punch_in == '0') and (not attendance.punch_out or attendance.punch_out == '0'):
                    if attendance_date_str in second_fourth_saturdays:
                        half_days += 1.0  # Only half-day if absent on 2nd/4th Saturday
                    else:
                        leave_days += 1.0
                    prev_attendance = attendance
                    continue

                if not attendance.punch_in or attendance.punch_in == '0':
                    half_days += 1.0
                    prev_attendance = attendance
                    continue

                try:
                    punch_in_time = datetime.strptime(attendance.punch_in, "%H:%M")
                    punch_out_time = None

                    if attendance.punch_out and attendance.punch_out != '0':
                        punch_out_time = datetime.strptime(attendance.punch_out, "%H:%M")

                    if not punch_out_time or punch_out_time == 0:
                        half_days += 1.0
                        prev_attendance = attendance
                        continue

                    if emp_shift == "09:00 - 18:00":
                        shift_start_time = datetime.strptime("09:00", "%H:%M")
                        shift_end_time = datetime.strptime("18:00", "%H:%M")
                    else:
                        shift_start_time = datetime.strptime("10:00", "%H:%M")
                        shift_end_time = datetime.strptime("19:00", "%H:%M")

                    if punch_in_time < shift_start_time:
                        overtime_minutes += (shift_start_time - punch_in_time).total_seconds() / 60

                    if punch_out_time > shift_end_time:
                        overtime_minutes += (punch_out_time - shift_end_time).total_seconds() / 60

                    if attendance_date_str not in second_fourth_saturdays:
                        if punch_in_time > (shift_start_time + timedelta(minutes=15)):
                            late_punches += 1.0
                            half_days += 1.0
                        elif punch_out_time < shift_end_time:
                            early_punches += 1.0
                            half_days += 1.0
                        else:
                            full_days += 1.0
                    else:
                        full_days += 1.0  # Consider full day even if it's not

                except ValueError:
                    continue

                prev_attendance = attendance
            
        
            month_work_hours = total_month_work_minutes // 60
            month_work_remaining_minutes = total_month_work_minutes % 60
            total_month_work_str = f"{month_work_hours}hr {month_work_remaining_minutes}m" if month_work_hours else f"{month_work_remaining_minutes}minutes"
            
            pure_worked_minutes = total_month_work_minutes - total_month_breaks
            pure_work_hours = pure_worked_minutes // 60
            pure_work_remaining_minutes = pure_worked_minutes % 60
            pure_month_work_str = f"{pure_work_hours}hr {pure_work_remaining_minutes}m" if pure_work_hours else f"{pure_work_remaining_minutes}minutes"
            
            # âœ… Corrected total_days_worked logic
            total_days_worked = float(len(unique_dates))
            
            # Ensure from_date and to_date are datetime objects
            if isinstance(from_date, str):
                from_date_dt = datetime.strptime(from_date, "%Y-%m-%d")
            else:
                from_date_dt = from_date
            
            if isinstance(to_date, str):
                to_date_dt = datetime.strptime(to_date, "%Y-%m-%d")
            else:
                to_date_dt = to_date
            
            # Then calculate total_month_days
            total_month_days = float((to_date_dt - from_date_dt).days + 1)

            overtime_hours = float(overtime_minutes // 60)
            overtime_remaining_minutes = float(overtime_minutes % 60)

            reports = tbl_daily_report.objects.filter(
                userId=user_id,
                reportDate__range=[from_date, to_date]
            )

            half_missing_reports = full_missing_reports = days_half_report = days_full_report = sunday_count = 0

            for report in reports:
                lep_entries = [report.lep1, report.lep2, report.lep3]
                missing_count = lep_entries.count("") + lep_entries.count("0")

                if missing_count == 0:
                    days_full_report += 1
                if missing_count >= 1:
                    days_half_report += 1
                if missing_count == 1:
                    half_missing_reports += 1
                elif missing_count == 2:
                    half_missing_reports += 2
                elif missing_count == 3:
                    full_missing_reports += 3

            reported_dates = set(report.reportDate.strftime('%Y-%m-%d') for report in reports)
            
            if isinstance(from_date, str):
                current = datetime.strptime(from_date, "%Y-%m-%d")
            else:
                current = from_date

            if isinstance(to_date, str):
                end = datetime.strptime(to_date, "%Y-%m-%d")
            else:
                end = to_date

            while current <= end:
                if current.weekday() == 6:
                    sunday_count += 1
                elif current.strftime('%Y-%m-%d') not in reported_dates:
                    full_missing_reports += 1
                current += timedelta(days=1)

            penalty_leaves = float(rejected_double_leave_days)
            penalty_halfs = 0.5 * float(rejected_double_half_days)

            penalty_leaves += float(unapplied_leaves )
            penalty_halfs += 0.5 * float(unapplied_half_days )

            final_leaves = float(leave_days) + float(penalty_leaves) + 0.5 * float(half_days) + float(penalty_halfs)

            # paid_days = float(full_days)
            # paid_days += float(sunday_attendances)
            # paid_days += 0.5 * float(half_days)
            # # leave_days_ = float(leave_days)
            # # leave_days_ += 0.5 * float(half_days)
            # leave_days_ = float(final_leaves)

            paid_days = float(full_days) - (float(penalty_halfs) + float(penalty_leaves)) + len(exception_leave_dates) + holiday_count
            paid_days += float(sunday_attendances)
            paid_days += 0.5 * float(half_days)
            # leave_days_ = float(leave_days)
            # leave_days_ += 0.5 * float(half_days)
            leave_days_ = float(final_leaves) + len(exception_leave_dates) + holiday_count

            if leave_days_:
                if leave_days_ == 0.5:
                    paid_days += 0.5
                elif leave_days_ == 1:
                    paid_days += 1
                elif leave_days_ >= 1.5:
                    paid_days += 1.5

            emp_salary = float(employee.gross_sal or 0.0)
            per_day_salary = emp_salary / total_month_days if total_month_days else 0.0
            amount = round(per_day_salary * paid_days, 2)

            advance_salary = tbl_adv_salary.objects.filter(emp_id=emp_id, salary_date__range=(from_date, to_date))
            adv_amount = sum(adv.adv_salary for adv in advance_salary)

            leaves_list = []
            for leave in leave_apps.values('leave_type', 'app_start_date', 'app_end_date', 'reason', 'status'):
                leave['app_start_date'] = leave['app_start_date'].strftime('%d-%m-%Y')
                leave['app_end_date'] = leave['app_end_date'].strftime('%d-%m-%Y')
                leaves_list.append(leave)
            
            task_list = [
                {
                    **task,
                    'assign_date': task['assign_date'].strftime('%d-%m-%Y') if task['assign_date'] else None,
                    'complete_date': task['complete_date'].strftime('%d-%m-%Y') if task['complete_date'] else None
                }
                for task in tasks.values(
                    'task_type',
                    'assign_date',
                    'complete_date',
                    'task_name',
                    'status',
                    'description',
                    'delay_count'
                )
            ]
            exception_leaves_count = len(exception_leave_dates)
            if isinstance(from_date, str):
                from_date_obj = datetime.strptime(from_date, "%Y-%m-%d")
            else:
                from_date_obj = from_date
            
            if isinstance(to_date, str):
                to_date_obj = datetime.strptime(to_date, "%Y-%m-%d")
            else:
                to_date_obj = to_date
            
            context = {
                'emp_id': employee.emp_id,
                'full_name': full_name,
                'company_name': company_name,
                'company_address': company_address, 
                'exception_leaves': exception_leaves_count,
                'breaks': breaks_data,
                'm_total_break_str': total_month_breaks_str,
                'total_month_worked_hours': total_month_work_str,
                'pure_month_work_str': pure_month_work_str,
                'holiday_count': holiday_count,
                'final_leaves': final_leaves,
                'paid_days': paid_days,
                'amount': amount,
                'adv_amount': adv_amount,
                'tax': 200,
                'emp_salary': emp_salary,
                'after_deductions': amount - adv_amount - 200,
                'leaves_data': leaves_list,
                'attendances': attendance_data,
                'total_days_worked': total_days_worked,
                'total_month_days': total_month_days,
                'full_days': full_days,
                'half_days': half_days,
                'late_punches': late_punches,
                'early_punches': early_punches,
                'sunday_attendances': sunday_attendances,
                'leave_days': leave_days,
                'rejected_double_leave_days': rejected_double_leave_days,
                'rejected_double_half_days': rejected_double_half_days,
                'overtime_hours': overtime_hours,
                'overtime_remaining_minutes': overtime_remaining_minutes,
                # 'from_date': datetime.strptime(from_date, "%Y-%m-%d").strftime("%d-%m-%Y"),
                # 'to_date': datetime.strptime(to_date, "%Y-%m-%d").strftime("%d-%m-%Y"),
                'from_date': from_date_obj.strftime("%d-%m-%Y"),
                'to_date': to_date_obj.strftime("%d-%m-%Y"),
                # 'tasks': list(tasks.values('task_type', 'task_name', 'status', 'description', 'delay_count')),
                'tasks': task_list,
                'total_task': total_task,
                'complete_task': complete_task,
                'pending_task': pending_task,
                'revised_task': revised_task,
                'task_delay': task_delay,
                'half_missing_reports': half_missing_reports,
                'full_missing_reports': full_missing_reports,
                'days_half_report': days_half_report,
                'days_full_report': days_full_report,
                'date_range': date_range,
                'unapplied_leaves': unapplied_leaves ,
                'unapplied_half_days': unapplied_half_days ,
                'sunday_count': sunday_count,
                'session_roleid': session_roleid
            }
            
            if action == "download":
                response = HttpResponse(content_type='application/pdf')
                response['Content-Disposition'] = f'attachment; filename="Intern_Report_{emp_id}.pdf"'
            
                p = canvas.Canvas(response, pagesize=letter)
                width, height = letter
            
                # Title & Header Info
                p.setFont("Helvetica-Bold", 16)
                p.drawString(200, height - 40, "Intern Report")
            
                p.setFont("Helvetica", 11)
                p.drawString(50, height - 80, f"Intern ID: {employee.intern_id_custom}")
                p.drawString(250, height - 80, f"From: {context['from_date']} To: {context['to_date']}")
                p.drawString(50, height - 95, f"Employee Name: {context['full_name']}")
                p.drawString(50, height - 110, f"Employee Company: {context['company_name']}")
            
                y = height - 140  # Added more spacing
            
                # Attendance Details
                p.setFont("Helvetica-Bold", 16)
                p.drawString(50, y, "Attendance Details")
                y -= 20  # Space after section title
            
                p.setFont("Helvetica-Bold", 13)
                p.drawString(60, y, "Description")
                p.drawString(180, y, "Details")
                p.drawString(320, y, "Description")
                p.drawString(440, y, "Details")
                y -= 12
                p.line(55, y, 500, y)
                y -= 16
            
                p.setFont("Helvetica", 11)
                salary_details = [
                    # ("From Date", datetime.strptime(from_date, "%Y-%m-%d").strftime("%d-%m-%Y")),
                    # ("To Date", datetime.strptime(to_date, "%Y-%m-%d").strftime("%d-%m-%Y")),
                    ("From Date", from_date.strftime("%d-%m-%Y") if isinstance(from_date, datetime) else datetime.strptime(from_date, "%Y-%m-%d").strftime("%d-%m-%Y")),
                    ("To Date", to_date.strftime("%d-%m-%Y") if isinstance(to_date, datetime) else datetime.strptime(to_date, "%Y-%m-%d").strftime("%d-%m-%Y")),
                    ("Total Days", context['total_month_days']),
                    ("Total Days Worked", context['total_days_worked']),
                    ("Sundays", context['sunday_attendances']),
                    ("Holidays", context['holiday_count']),
                    ("Leaves", context['leave_days']),
                    ("Full Days", context['full_days']),
                    ("Half Days", context['half_days']),
                    ("Late Punches", context['late_punches']),
                    ("Early Punches", context['early_punches']),
                    ("Rejected Leaves Taken", context['rejected_double_leave_days']),
                    ("Rejected Halfs Taken", context['rejected_double_half_days']),
                    ("Total Overtime", f"{context['overtime_hours']} hours {context['overtime_remaining_minutes']} minutes"),
                    ("Exception leaves", context['exception_leaves']),
                    ("leaves including penalty", context['final_leaves']),
                ]
            
                for i in range(0, len(salary_details), 2):
                    label1, value1 = salary_details[i]
                    p.drawString(60, y, str(label1)[:25])
                    p.drawString(180, y, str(value1))
            
                    if i + 1 < len(salary_details):
                        label2, value2 = salary_details[i + 1]
                        p.drawString(320, y, str(label2)[:25])
                        p.drawString(440, y, str(value2))
            
                    y -= 16  # Increased spacing between rows
            
                y -= 20  # Extra space before next section
            
                # # Salary Details
                # p.setFont("Helvetica-Bold", 16)
                # p.drawString(50, y, "Salary Details")
                # y -= 20
            
                # p.setFont("Helvetica-Bold", 13)
                # p.drawString(60, y, "Description")
                # p.drawString(300, y, "Details")
                # y -= 12
                # p.line(55, y, 500, y)
                # y -= 16
            
                # p.setFont("Helvetica", 11)
                # salary_details = [
                #     ("Employee Salary", context['emp_salary']),
                #     ("Paid Days", context['paid_days']),
                #     ("Paid days Amount", context['amount']),
                #     ("Advance Amount", context['adv_amount']),
                #     ("Tax", context['tax']),
                #     ("After Deductions", context['after_deductions']),
                # ]
            
                # for label, value in salary_details:
                #     p.drawString(60, y, str(label)[:40])
                #     p.drawString(300, y, str(value))
                #     y -= 16
            
                # y -= 20
            
                # Task Summary
                p.setFont("Helvetica-Bold", 16)
                p.drawString(50, y, "Task Summary (Counts)")
                y -= 20
            
                p.setFont("Helvetica-Bold", 13)
                p.drawString(60, y, "Description")
                p.drawString(300, y, "Details")
                y -= 12
                p.line(55, y, 500, y)
                y -= 16
            
                p.setFont("Helvetica", 11)
                summary_data = [
                    ("Total Tasks", context['total_task']),
                    ("Completed Tasks", context['complete_task']),
                    ("Pending Tasks", context['pending_task']),
                    ("Revised Tasks", context['revised_task']),
                    ("Total Delay", f"{context['task_delay']} days"),
                ]
            
                for label, value in summary_data:
                    if label == "Total Delay":
                        p.setFont("Helvetica-Bold", 11)
                        p.line(55, y, 500, y)
                        y -= 14
            
                    p.setFont("Helvetica", 11)
                    p.drawString(60, y, str(label)[:40])
                    p.drawString(300, y, str(value))
                    y -= 16
            
                y -= 20
            
                # Daily Report Summary
                p.setFont("Helvetica-Bold", 16)
                p.drawString(50, y, "Daily Report Summary")
                y -= 18
            
                lep_summary = [
                    ("Half Missing Reports", context['half_missing_reports']),
                    ("No. of days (Half Missing Reports)", context['days_half_report']),
                    ("No. of days (Complete Reports)", context['days_full_report']),
                    ("No. of days (No report at all excluding Sunday)", context['full_missing_reports']),
                    ("No. of Sundays (No Reports)", context['sunday_count']),
                ]
            
                p.setFont("Helvetica-Bold", 13)
                p.drawString(60, y, "Description")
                p.drawString(400, y, "Details")
                y -= 12
                p.line(55, y, 500, y)
                y -= 16
            
                p.setFont("Helvetica", 11)
                for label, value in lep_summary:
                    p.drawString(60, y, label[:40])
                    p.drawString(400, y, str(value))
                    y -= 16
            
                # Finalize the PDF
                p.save()
                return response
    
            else:
                request.session['details_context'] = context
                request.session['ss_context'] = context
                return redirect('intern_details', emp_id=emp_id)

        else:
            return render(request, "intern_details.html", {
                'error_message': "Please select a valid date range.",
                'session_roleid': session_roleid
            })
    else:
        return redirect('login')

def salary_history(request):
    if 'session_id' in request.session:
        session_id = request.session.get('session_id')
        session_roleid = request.session.get('session_roleid')
        company_id = request.session['company_id']
        user_compeny = request.session['user_compney']
        Username = request.session['session_user']  
        employees = tbl_employee.objects.all().order_by("name")
           
        return render(request, "salary-history-form.html", {
                'employees': employees,
                'Username': Username,
                'comp_name': user_compeny,
                'session_roleid': session_roleid,
                'companey_list': master_company.objects.all(),
                'company_id': company_id
            })
    else:
        return redirect(login)


def add_salary_history(request):
    if 'session_id' in request.session:
        Username = request.session['session_user']
        user_compeny = request.session['user_compney']
        session_roleid = request.session.get('session_roleid')
        
        if request.method == 'POST':
            userid = request.session['session_id']
            salary = request.POST['salary']
            emp_id = request.POST['emp_id']
            
            employee = tbl_employee.objects.get(emp_id=emp_id)
            name = f"{employee.name} {employee.middle_name} {employee.last_name}"
            
            increment_date = request.POST['increment_date']
            
            new_record = tbl_salary_history.objects.create(
                salary = salary,
                emp_id = emp_id,
                name = name,
                increment_date = increment_date,
                add_by_name=Username,
                add_by_id=userid,
                created_date = timezone.now() + timedelta(hours=5, minutes=30),
            )
            new_record.save()
            
            ip_address = get_client_ip(request)
            tbl_messages.objects.create(
                message_name = request.session['session_user'],
                change_status=f"Add salary_history - {name}",
                added_date = timezone.now() + timedelta(hours=5, minutes=30),
                company_id = request.session['company_id'],
                user_id = request.session['session_id'],
                ip_address = ip_address,
            )
            
            log_user_activity(
                ope='Add salary_history',
                comment='Added a salary history.',
                lanti=None,  
                longti=None,  
                by_user_id=userid,
                by_user_name=Username,
                status='online'
            )
            return JsonResponse({'status': 'success', 'message': f'Salary history {name} added successfully!'})
        return render(request, "salary_history-leasting.html",{'session_roleid':session_roleid})
    else:
        return redirect(login)
 
def salary_record(request):
    if 'session_id' in request.session:
        session_id = request.session.get('session_id')
        session_roleid = request.session.get('session_roleid')
        company_id = request.session['company_id']
        user_compeny = request.session['user_compney']
        Username = request.session['session_user']  
        employees = tbl_employee.objects.all().order_by("name")
           
        return render(request, "salary-history-form_.html", {
                'employees': employees,
                'Username': Username,
                'comp_name': user_compeny,
                'session_roleid': session_roleid,
                'companey_list': master_company.objects.all(),
                'company_id': company_id
            })
    else:
        return redirect(login)

def add_salary_record(request, emp_id):
    if 'session_id' in request.session:
        Username = request.session['session_user']
        user_compeny = request.session['user_compney']
        session_roleid = request.session.get('session_roleid')
        employee = tbl_employee.objects.get(emp_id=emp_id)
        name = f"{employee.name} {employee.middle_name} {employee.last_name}"
        
        if request.method == 'POST':
            userid = request.session['session_id']
            salary = request.POST['salary']

            increment_date = request.POST['increment_date']
            
            new_record = tbl_salary_history.objects.create(
                salary = salary,
                emp_id = emp_id,
                name = name,
                increment_date = increment_date,
                add_by_name=Username,
                add_by_id=userid,
                created_date = timezone.now() + timedelta(hours=5, minutes=30),
            )
            new_record.save()
            
            ip_address = get_client_ip(request)
            tbl_messages.objects.create(
                message_name = request.session['session_user'],
                change_status=f"Add salary_history - {name}",
                added_date = timezone.now() + timedelta(hours=5, minutes=30),
                company_id = request.session['company_id'],
                user_id = request.session['session_id'],
                ip_address = ip_address,
            )
            
            log_user_activity(
                ope='Add salary_history',
                comment='Added a salary history.',
                lanti=None,  
                longti=None,  
                by_user_id=userid,
                by_user_name=Username,
                status='online'
            )
            return JsonResponse({'status': 'success', 'message': f'Salary history {name} added successfully!'})
        return render(request, "salary-history-form_.html",{'session_roleid':session_roleid, "employee_id":employee.emp_id})
    else:
        return redirect(login)
 
def edit_salary_record(request, id , emp_id):
    if 'session_id' not in request.session:
        return redirect(login)

    session_roleid = request.session.get('session_roleid')
    company_data = master_company.objects.all()
    salary_history = get_object_or_404(tbl_salary_history, id=id)
    
    employee = tbl_employee.objects.get(emp_id=salary_history.emp_id)
    salary_history.name = f"{employee.name} {employee.middle_name} {employee.last_name}"

    if request.method == 'POST':
        # salary_history.emp_id = request.POST.get('emp_id')
        salary_history.salary = request.POST.get('salary')
        salary_history.increment_date = request.POST.get('increment_date')
        
        
        salary_history.save()

        ip_address = get_client_ip(request)
        tbl_messages.objects.create(
            message_name=request.session['session_user'],
            change_status=f"Edit salary_history - {salary_history.name}",
            added_date=timezone.now() + timedelta(hours=5, minutes=30),
            company_id=request.session['company_id'],
            user_id=request.session['session_id'],
            ip_address=ip_address,
        )

        return JsonResponse({
            'status': 'success',
            'message': f'Salary history "{salary_history.name}" has been successfully updated!'
        })

    data = tbl_salary_history.objects.get(id=id)

    return render(request, "salary-history-form_.html", {
        'company_data': company_data,
        'lead': salary_history,
        'employee_id': employee.emp_id,
        'session_roleid': session_roleid,
        'is_edit': True
    })


def salary_history_list(request):
    if 'session_id' in request.session:
        session_id = request.session.get('session_id')
        session_roleid = request.session.get('session_roleid')
        company_id = request.session['company_id']
        user_compeny = request.session['user_compney']
        Username = request.session['session_user']
            
        data = tbl_salary_history.objects.all().order_by("-id") 

            
        return render(request, "salary-history-list.html", {
            'data': data,
            'Username': Username,
            'comp_name': user_compeny,
            'session_roleid': session_roleid,
            'company_id': company_id
            })
    else:
        return redirect(login)




def edit_salary_history(request, id):
    if 'session_id' not in request.session:
        return redirect(login)

    session_roleid = request.session.get('session_roleid')
    company_data = master_company.objects.all()
    salary_history = get_object_or_404(tbl_salary_history, id=id)
    
    employee = tbl_employee.objects.get(emp_id=salary_history.emp_id)
    salary_history.name = f"{employee.name} {employee.middle_name} {employee.last_name}"

    if request.method == 'POST':
        # salary_history.emp_id = request.POST.get('emp_id')
        salary_history.salary = request.POST.get('salary')
        salary_history.increment_date = request.POST.get('increment_date')
        
        
        salary_history.save()

        ip_address = get_client_ip(request)
        tbl_messages.objects.create(
            message_name=request.session['session_user'],
            change_status=f"Edit salary_history - {salary_history.name}",
            added_date=timezone.now() + timedelta(hours=5, minutes=30),
            company_id=request.session['company_id'],
            user_id=request.session['session_id'],
            ip_address=ip_address,
        )

        return JsonResponse({
            'status': 'success',
            'message': f'Salary history "{salary_history.name}" has been successfully updated!'
        })

    data = tbl_salary_history.objects.get(id=id)

    return render(request, "salary-history-form.html", {
        'company_data': company_data,
        'lead': salary_history,
        'employee_id': employee.emp_id,
        'session_roleid': session_roleid,
        'is_edit': True
    })

def delete_salary_history(request, id):
    if 'session_id' in request.session:
        salary_history = get_object_or_404(tbl_salary_history, id=id)
        
        ip_address = get_client_ip(request)
        tbl_messages.objects.create(
            message_name = request.session['session_user'],
            change_status=f"Delete salary_history - {salary_history.name}",
            added_date = timezone.now() + timedelta(hours=5, minutes=30),
            company_id = request.session['company_id'],
            user_id = request.session['session_id'],
            ip_address = ip_address,
        )
        
        salary_history.delete()
        return JsonResponse({'success': True, 'name': salary_history.name})
    
    else:
        return redirect(login)

