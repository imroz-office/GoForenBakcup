from django.urls import path,re_path
from django.conf.urls.static import static
from django.conf import settings
# from .views import InitiatePhonePePayment
from . import views
from . import views2

import hashlib

def hashed_url(part: str) -> str:
    return hashlib.sha256(part.encode()).hexdigest()[:10]

urlpatterns = [
    #Login
        path("", views.login, name='login'),
        path('logout/', views.logout_view, name='logout'),
        path(f'{hashed_url("unlock_screen")}/', views.unlock_screen, name='unlock_screen'),
        path(f'{hashed_url("deactivate_completed_interns")}/', views.deactivate_completed_interns, name='deactivate_completed_interns'),
        path(f'{hashed_url("deactivate_old_employees")}/', views.deactivate_old_employees, name='deactivate_old_employees'),
         path(f'{hashed_url("change-photo")}/', views.change_photo, name='change_photo'),

    # Common Functin
        path(f'{hashed_url("index")}/', views.index, name='index'),  
        path(f'{hashed_url("profile")}/', views.profile, name='profile'),  
        path(f'{hashed_url("profile_Update")}/', views.profile_Update, name='profile_Update'), 
        path(f'{hashed_url("change_Password")}/', views.change_Password, name='change_Password'), 
        
        path(f'{hashed_url("Log")}/', views.Log, name='Log'),
        # path(f'{hashed_url("fetch_new_messages")}/', views.fetch_new_messages, name='fetch_new_messages'),
        # path(f'{hashed_url("fetch_companies")}/', views.fetch_companies, name='fetch_companies'),
        path('fetch_new_messages/', views.fetch_new_messages, name='fetch_new_messages'),
        path('fetch_companies/', views.fetch_companies, name='fetch_companies'),

        path(f'{hashed_url("save_selected_company")}/', views.save_selected_company, name='save_selected_company'),
        
        path(f'{hashed_url("today_meeting")}/', views.today_meeting, name='today_meeting'),
        path(f'{hashed_url("new_lead")}/', views.new_lead, name='new_lead'),
        
        path(f'{hashed_url("account_today_expense")}/', views.account_today_expense, name='account_today_expense'), 
         
        path(f'{hashed_url("today_amc")}/', views.today_amc, name='today_amc'), 
         
        path(f'{hashed_url("smo_today_renewal")}/', views.smo_today_renewal, name='smo_today_renewal'), 
        path(f'{hashed_url("smo_active_client")}/', views.smo_active_client, name='smo_active_client'), 
        
    # Master
        path(f'{hashed_url("company")}/', views.company, name='company'),   
        path(f'{hashed_url("add_company")}/', views.add_company, name='add_company'),
        path(f'{hashed_url("update_company")}/<int:com_id>/', views.update_company, name='update_company'),
        # path(f'{hashed_url("delete_company")}/<int:com_id>/', views.delete_company, name='delete_company'),
        path('delete_company/<int:com_id>/', views.delete_company, name='delete_company'),

        path(f'{hashed_url("company_view")}/<int:com_id>/', views.company_view, name='company_view'),
        # path(f'{hashed_url("get_departments_by_company")}/', views.get_departments_by_company, name='get_departments_by_company'), 
        path('get_departments_by_company/', views.get_departments_by_company, name='get_departments_by_company'), 
        
        path(f'{hashed_url("department")}/', views.department, name='department'),
        path(f'{hashed_url("add_department")}/', views.add_department, name='add_department'),
        path(f'{hashed_url("update_department")}/<int:dp_id>/', views.update_department, name='update_department'),
        # path(f'{hashed_url("delete_department")}/<int:dp_id>/', views.delete_department, name='delete_department'),
        path('delete_department/<int:dp_id>/', views.delete_department, name='delete_department'),

        
        path(f'{hashed_url("lead_source")}/', views.lead_source, name='lead_source'),
        path(f'{hashed_url("add_lead_source")}/', views.add_lead_source, name='add_lead_source'),
        path(f'{hashed_url("update_lead_source")}/<int:ldt_id>/', views.update_lead_source, name='update_lead_source'),
        # path(f'{hashed_url("delete_lead_source")}/<int:ldt_id>/', views.delete_lead_source, name='delete_lead_source'),
        path('delete_lead_source/<int:ldt_id>/', views.delete_lead_source, name='delete_lead_source'),

        
        path(f'{hashed_url("shift_list")}/', views.shift_list, name='shift_list'),
        path(f'{hashed_url("add_shift")}/', views.add_shift, name='add_shift'),
        path(f'{hashed_url("update_shift")}/<int:s_id>/', views.update_shift, name='update_shift'),
        # path(f'{hashed_url("delete_shift")}/<int:s_id>/', views.delete_shift, name='delete_shift'),
        path('delete_shift/<int:s_id>/', views.delete_shift, name='delete_shift'),

        
        path(f'{hashed_url("Product")}/', views.Product, name='Product'),
        path(f'{hashed_url("add_product")}/', views.add_product, name='add_product'),
        path(f'{hashed_url("update_product")}/<int:pro_id>/', views.update_product, name='update_product'),
        # path(f'{hashed_url("delete_product")}/<int:pro_id>/', views.delete_product, name='delete_product'),
        path('delete_product/<int:pro_id>/', views.delete_product, name='delete_product'),

        
        path(f'{hashed_url("Reason")}/', views.Reason, name='Reason'),
        path(f'{hashed_url("add_reason")}/', views.add_reason, name='add_reason'),
        path(f'{hashed_url("update_reason")}/<int:id>/', views.update_reason, name='update_reason'),
        # path(f'{hashed_url("delete_reason")}/<int:id>/', views.delete_reason, name='delete_reason'), 
        path('delete_reason/<int:id>/', views.delete_reason, name='delete_reason'), 

        
        path(f'{hashed_url("Promocode")}/', views.Promocode, name='Promocode'),
        path(f'{hashed_url("Promocode_view")}/', views.Promocode_view, name='Promocode_view'),
        path(f'{hashed_url("add_promocode")}/', views.add_promocode, name='add_promocode'),
        path(f'{hashed_url("update_promocode")}/<int:id>/', views.update_promocode, name='update_promocode'),
        # path(f'{hashed_url("delete_promocode")}/<int:id>/', views.delete_promocode, name='delete_promocode'), 
        path('delete_promocode/<int:id>/', views.delete_promocode, name='delete_promocode'), 

        
        path("initiate_payment/", views2.initiate_payment, name='initiate_payment'), 
        path('payment_callback/', views2.payment_callback, name='payment_callback'),
        
        path(f'{hashed_url("Holiday")}/', views.Holiday, name='Holiday'),
        path(f'{hashed_url("add_holiday")}/', views.add_holiday, name='add_holiday'),
        path(f'{hashed_url("update_holiday")}/<int:id>/', views.update_holiday, name='update_holiday'), 
        # path(f'{hashed_url("delete_holiday")}/<int:id>/', views.delete_holiday, name='delete_holiday'),
        path('delete_holiday/<int:id>/', views.delete_holiday, name='delete_holiday'),

        
        path(f'{hashed_url("Area")}/', views.Area, name='Area'),
        path(f'{hashed_url("add_area")}/', views.add_area, name='add_area'),
        path(f'{hashed_url("update_area")}/<int:id>/', views.update_area, name='update_area'), 
        # path(f'{hashed_url("delete_area")}/<int:id>/', views.delete_area, name='delete_area'),
        path('delete_area/<int:id>/', views.delete_area, name='delete_area'),

        
        path(f'{hashed_url("Inqiry_for")}/', views.Inqiry_for, name='Inqiry_for'),
        path(f'{hashed_url("add_inqiry_for")}/', views.add_inqiry_for, name='add_inqiry_for'),
        path(f'{hashed_url("up_inqfor")}/<int:id>/', views.up_inqfor, name='up_inqfor'),
        # path(f'{hashed_url("delete_inqiry_for")}/<int:id>/', views.delete_inqiry_for, name='delete_inqiry_for'), 
        path('delete_inqiry_for/<int:id>/', views.delete_inqiry_for, name='delete_inqiry_for'), 

        path(f'{hashed_url("Business_segment")}/', views.Business_segment, name='Business_segment'),
        path(f'{hashed_url("add_busi_seg")}/', views.add_busi_seg, name='add_busi_seg'),
        path(f'{hashed_url("up_segment")}/<int:id>/', views.up_segment, name='up_segment'),
        # path(f'{hashed_url("delete_segment")}/<int:id>/', views.delete_segment, name='delete_segment'), 
        path('delete_segment/<int:id>/', views.delete_segment, name='delete_segment'), 

        
        path(f'{hashed_url("SMO_Plan")}/', views.SMO_Plan, name='SMO_Plan'),
        path(f'{hashed_url("add_smo_plan")}/', views.add_smo_plan, name='add_smo_plan'),
        path(f'{hashed_url("update_smo_plan")}/<int:id>/', views.update_smo_plan, name='update_smo_plan'),
        # path(f'{hashed_url("delete_smo_plan")}/<int:id>/', views.delete_smo_plan, name='delete_smo_plan'),
        path('delete_smo_plan/<int:id>/', views.delete_smo_plan, name='delete_smo_plan'),
        
        path(f'{hashed_url("SEO_Plan")}/', views.SEO_Plan, name='SEO_Plan'),
        path(f'{hashed_url("add_seo_plan")}/', views.add_seo_plan, name='add_seo_plan'),
        path(f'{hashed_url("update_seo_plan")}/<int:id>/', views.update_seo_plan, name='update_seo_plan'),
        # path(f'{hashed_url("delete_seo_plan")}/<int:id>/', views.delete_seo_plan, name='delete_seo_plan'),
        path('delete_seo_plan/<int:id>/', views.delete_seo_plan, name='delete_seo_plan'),

        
    # User
        path(f'{hashed_url("User")}/', views.User, name='User'),
        path(f'{hashed_url("user_excel")}/', views.user_excel, name='user_excel'),
        path(f'{hashed_url("add_user")}/', views.add_user, name='add_user'),
        path(f'{hashed_url("edit_user")}/<int:user_id>/', views.edit_user, name='edit_user'),
        # path(f'{hashed_url("delete_user")}/<int:userId>/', views.delete_user, name='delete_user'),
        path('delete_user/<int:userId>/', views.delete_user, name='delete_user'),
        path(f'{hashed_url("view_user")}/<int:userId>/', views.view_user, name='view_user'),

    # CRM
        path(f'{hashed_url("crm_dashboard")}/', views.crm_dashboard, name='crm_dashboard'),
        path(f'{hashed_url("inquiry")}/', views.inquiry, name='inquiry'),
        path(f'{hashed_url("fresh_inquiry")}/', views.fresh_inquiry, name='fresh_inquiry'),
        path(f'{hashed_url("today_followup")}/', views.today_followup, name='today_followup'),
        path(f'{hashed_url("pending_followup")}/', views.pending_followup, name='pending_followup'),
        path(f'{hashed_url("Meeting_inquiry")}/', views.Meeting_inquiry, name='Meeting_inquiry'),
        path(f'{hashed_url("Contacted_inquiry")}/', views.Contacted_inquiry, name='Contacted_inquiry'),
        path(f'{hashed_url("Quotation_inquiry")}/', views.Quotation_inquiry, name='Quotation_inquiry'),
        path(f'{hashed_url("Contracted_inquiry")}/', views.Contracted_inquiry, name='Contracted_inquiry'),
        path(f'{hashed_url("Onhold_inquiry")}/', views.Onhold_inquiry, name='Onhold_inquiry'),
        path(f'{hashed_url("Lost_inquiry")}/', views.Lost_inquiry, name='Lost_inquiry'),
        path(f'{hashed_url("today_meetings")}/', views.today_meetings, name='today_meetings'), 
        path(f'{hashed_url("today_dcr")}/', views.today_dcr, name='today_dcr'), 
        path(f'{hashed_url("upload_lead")}/', views.upload_lead, name='upload_lead'),
        
        path(f'{hashed_url("lead_list")}/', views.lead_list, name='lead_list'),
        path(f'{hashed_url("addlead")}/', views.addlead, name='addlead'),
        path(f'{hashed_url("lead_excel")}/', views.lead_excel, name='lead_excel'),
        path(f'{hashed_url("add_lead")}/', views.add_lead, name='add_lead'),
        path(f'{hashed_url("edit_lead")}/<int:l_id>/', views.edit_lead, name='edit_lead'),
        # path(f'{hashed_url("delete_lead")}/<int:l_id>/', views.delete_lead, name='delete_lead'),
        path('delete_lead/<int:l_id>/', views.delete_lead, name='delete_lead'),
        path(f'{hashed_url("lead_view")}/<int:l_id>/', views.lead_view, name='lead_view'),
        path(f'{hashed_url("lead_update_view")}/<int:l_id>/', views.lead_update_view, name='lead_update_view'),
        path(f'{hashed_url("edit_lead_status")}/<int:l_id>/', views.edit_lead_status, name='edit_lead_status'),
        
        # path(f'{hashed_url("assign_lead")}/', views.assign_lead, name='assign_lead'),
        path('assign_lead/', views.assign_lead, name='assign_lead'),

        # path(f'{hashed_url("delete_select_leads")}/', views.delete_select_leads, name='delete_select_leads'),
        path('delete_select_leads/', views.delete_select_leads, name='delete_select_leads'),

        # path(f'{hashed_url("assign_leads")}/', views.assign_leads, name='assign_leads'),
        path('assign_leads/', views.assign_leads, name='assign_leads'),


        path(f'{hashed_url("add_dcr")}/', views.add_dcr, name='add_dcr'),
        path(f'{hashed_url("adddcr")}/', views.adddcr, name='adddcr'),
        
        path(f'{hashed_url("dcr_list")}/', views.dcr_list, name='dcr_list'),
        path(f'{hashed_url("dcr_excel")}/', views.dcr_excel, name='dcr_excel'), 
        path(f'{hashed_url("open_dcr_view")}/<int:l_id>/', views.open_dcr_view, name='open_dcr_view'), 
        path(f'{hashed_url("edit_dcr")}/<int:l_id>/', views.edit_dcr, name='edit_dcr'), 
        # path('delete_dcr/<int:l_id>/', views.delete_dcr, name='delete_dcr'),
        path('delete_dcr/<int:l_id>/', views.delete_dcr, name='delete_dcr'),
        path(f'{hashed_url("convert_lead")}/<int:l_id>/', views.convert_lead, name='convert_lead'),
        path(f'{hashed_url("convert_lead_bulk")}/', views.convert_lead_bulk, name='convert_lead_bulk'),
         
        path(f'{hashed_url("open_report_least_page")}/', views.open_report_least_page, name='open_report_least_page'),
        
        path(f'{hashed_url("client_excel")}/', views.client_excel, name='client_excel'), 
        
    # Account
        path(f'{hashed_url("open_ledger_least_page")}/', views.open_ledger_least_page, name='open_ledger_least_page'),
        
        path(f'{hashed_url("open_client_vendor_least_page")}/', views.open_client_vendor_least_page, name='open_client_vendor_least_page'),
        path(f'{hashed_url("open_add_client_page")}/', views.open_add_client_page, name='open_add_client_page'),
        path(f'{hashed_url("add_client_page")}/', views.add_client_page, name='add_client_page'),
        path(f'{hashed_url("open_edit_client")}/<int:cId>/', views.open_edit_client, name='open_edit_client'), 
        # path(f'{hashed_url("open_delete_client")}/<int:cId>/', views.open_delete_client, name='open_delete_client'),
        path('open_delete_client/<int:cId>/', views.open_delete_client, name='open_delete_client'),
        
        path(f'{hashed_url("open_employee_other_least_page")}/', views.open_employee_other_least_page, name='open_employee_other_least_page'),
        
    # voucher
        path(f'{hashed_url("account_dashboard")}/', views.account_dashboard, name='account_dashboard'),
        path(f'{hashed_url("account_client")}/', views.account_client, name='account_client'),
        path(f'{hashed_url("account_add_client")}/', views.account_add_client, name='account_add_client'),
        path(f'{hashed_url("account_edit_client")}/<int:clt_id>/', views.account_edit_client, name='account_edit_client'),
        # path(f'{hashed_url("account_delete_client")}/<int:clt_id>/', views.account_delete_client, name='account_delete_client'),
        path('account_delete_client/<int:clt_id>/', views.account_delete_client, name='account_delete_client'),
        path(f'{hashed_url("account_view_client")}/<int:clt_id>/', views.account_view_client, name='account_view_client'),
    
        path(f'{hashed_url("payment_voucher")}/', views.payment_voucher, name='payment_voucher'),
        path(f'{hashed_url("receipt_excel")}/', views.receipt_excel, name='receipt_excel'),
        path(f'{hashed_url("create_payment_voucher")}/', views.create_payment_voucher, name='create_payment_voucher'),
        path(f'{hashed_url("edit_payment")}/<int:pv_id>/', views.edit_payment, name='edit_payment'),
        # path(f'{hashed_url("delete_payment_voucher")}/<int:pv_id>/', views.delete_payment_voucher, name='delete_payment_voucher'),
        path('delete_payment_voucher/<int:pv_id>/', views.delete_payment_voucher, name='delete_payment_voucher'),
        path(f'{hashed_url("view_payment")}/<int:pv_id>/', views.view_payment, name='view_payment'),
        path(f'{hashed_url("add_payment")}/', views.add_payment, name='add_payment'), 
        path(f'{hashed_url("payment_voucher_pdf")}/<int:pv_id>/', views.payment_voucher_pdf, name='payment_voucher_pdf'),
        path(f'{hashed_url("generate_payment_invoice")}/', views.generate_payment_invoice, name='generate_payment_invoice'),
        
        path(f'{hashed_url("add_receipt")}/', views.add_receipt, name='add_receipt'),
        path(f'{hashed_url("create_receipt_voucher")}/', views.create_receipt_voucher, name='create_receipt_voucher'),
        path(f'{hashed_url("edit_receipt")}/<int:rv_id>/', views.edit_receipt, name='edit_receipt'),
        # path(f'{hashed_url("delete_receipt_voucher")}/<int:rv_id>/', views.delete_receipt_voucher, name='delete_receipt_voucher'),
        path('delete_receipt_voucher/<int:rv_id>/', views.delete_receipt_voucher, name='delete_receipt_voucher'),
        path(f'{hashed_url("view_client_receipt_voucher")}/<int:rv_id>/', views.view_client_receipt_voucher, name='view_client_receipt_voucher'),
        path(f'{hashed_url("receipt_voucher")}/', views.receipt_voucher, name='receipt_voucher'),
        path(f'{hashed_url("receipt_voucher_pdf")}/<int:rv_id>/', views.receipt_voucher_pdf, name='receipt_voucher_pdf'),
        path(f'{hashed_url("generate_receipt_invoice")}/', views.generate_receipt_invoice, name='generate_receipt_invoice'),
        
        path(f'{hashed_url("client_voucher")}/', views.client_voucher, name='client_voucher'),
        path(f'{hashed_url("client_invoice")}/<str:name>/<int:clt_id>/', views.open_client_invoice_least_page, name='open_client_invoice_least_page'),
        re_path(r'^client_payment/(?P<name>[\w-]+)/(?P<clt_id>\d+)/$', views.open_client_payment_voucer_least_page, name='open_client_payment_voucer_least_page'),
        re_path(r'^client_recipt/(?P<name>[\w-]+)/(?P<clt_id>\d+)/$', views.open_client_recipt_voucer_least_page, name='open_client_recipt_voucer_least_page'),
        
        path(f'{hashed_url("payment_v_excel")}/', views.payment_v_excel, name='payment_v_excel'),
        
        
    # ledger
        path(f'{hashed_url("ledger")}/', views.ledger, name='ledger'),
        
    # invoice
        path(f'{hashed_url("invoice")}/', views.invoice, name='invoice'),
        path(f'{hashed_url("invoice_excel")}/', views.invoice_excel, name='invoice_excel'),
        
        path(f'{hashed_url("create_invoice")}/', views.create_invoice, name='create_invoice'),
        path(f'{hashed_url("invoice_listing")}/', views.invoice_listing, name='invoice_listing'),
        path(f'{hashed_url("edit")}-invoice/<int:inv_id>/', views.edit_invoice, name='edit_invoice'),
        # path(f'{hashed_url("delete_invoice")}/<int:inv_id>/', views.delete_invoice, name='delete_invoice'),
        path('delete_invoice/<int:inv_id>/', views.delete_invoice, name='delete_invoice'),
        path(f'{hashed_url("invoice_pdf")}/<str:invNumber>/', views.invoice_pdf, name='invoice_pdf'),
        path(f'{hashed_url("invoice_share")}/<str:invNumber>/', views.invoice_pdf_share, name='invoice_pdf_share'),
        
        path(f'{hashed_url("PI_list")}/', views.PI_list, name='PI_list'),
        path(f'{hashed_url("create_PI")}/', views.create_PI, name='create_PI'),
        path(f'{hashed_url("add_PI")}/', views.add_PI, name='add_PI'),
        path(f'{hashed_url("edit_PI")}/<int:pi_id>/', views.edit_PI, name='edit_PI'),
        # path(f'{hashed_url("delete_PI")}/<int:pi_id>/', views.delete_PI, name='delete_PI'),
        path('delete_PI/<int:pi_id>/', views.delete_PI, name='delete_PI'),

        path(f'{hashed_url("PI_pdf")}/<str:piNumber>/', views.PI_pdf, name='PI_pdf'),
        path(f'{hashed_url("PI_pdf_share")}/<str:piNumber>/', views.PI_pdf_share, name='PI_pdf_share'),
        path(f'{hashed_url("convert_invoice")}/<str:pi_id>/', views.convert_invoice, name='convert_invoice'),
        
    # report
        path(f'{hashed_url("reports")}/', views.reports, name='reports'),
        path(f'{hashed_url("payment_report")}/', views.payment_report, name='payment_report'),
        path(f'{hashed_url("receipt_report")}/', views.receipt_report, name='receipt_report'),
        path(f'{hashed_url("receipt_invoice")}/', views.receipt_invoice, name='receipt_invoice'),
        path(f'{hashed_url("total_pending")}/', views.total_pending, name='total_pending'),
        
        path(f'{hashed_url("download_report")}/', views.download_report, name='download_report'),
        path(f'{hashed_url("download_pdf")}/', views.download_pdf, name='download_pdf'),
        path(f'{hashed_url("download_excel")}/', views.download_excel, name='download_excel'),
        
        path(f'{hashed_url("profit_loss")}/', views.profit_loss, name='profit_loss'),
        path(f'{hashed_url("excel_report")}/', views.excel_report, name='excel_report'),
        path(f'{hashed_url("GSTR_1")}/', views.GSTR_1, name='GSTR_1'),
        path(f'{hashed_url("GSTR_3B")}/', views.GSTR_3B, name='GSTR_3B'),

        path(f'{hashed_url("client_project")}/', views.client_project, name='client_project'),
        path(f'{hashed_url("add_client_project")}/', views.add_client_project, name='add_client_project'),
        path(f'{hashed_url("add_client_pro")}/', views.add_client_pro, name='add_client_pro'),
        path(f'{hashed_url("edit_client_pro")}/<str:id>/', views.edit_client_pro, name='edit_client_pro'),
        # path(f'{hashed_url("delete_client_pro")}/<str:id>/', views.delete_client_pro, name='delete_client_pro'),
        path('delete_client_pro/<str:id>/', views.delete_client_pro, name='delete_client_pro'),

    # AMC
        path(f'{hashed_url("addamc")}/', views.addamc, name='addamc'),
        path(f'{hashed_url("add_amc")}/', views.add_amc, name='add_amc'),
        path(f'{hashed_url("AMC")}/', views.AMC, name='AMC'),
        path(f'{hashed_url("edit_amc")}/<int:amc_id>/', views.edit_amc, name='edit_amc'),
        # path(f'{hashed_url("delete_amc")}/<int:amc_id>/', views.delete_amc, name='delete_amc'),
        path('delete_amc/<int:amc_id>/', views.delete_amc, name='delete_amc'),
        path(f'{hashed_url("view_amc")}/<int:amc_id>/', views.view_amc, name='view_amc'),
        path(f'{hashed_url("AMC_excel")}/', views.AMC_excel, name='AMC_excel'),
        
    # SMO/SEO
        path(f'{hashed_url("add_smo")}/', views.add_smo, name='add_smo'),
        path(f'{hashed_url("addsmo")}/', views.addsmo, name='addsmo'),
        path(f'{hashed_url("edit_smo")}/<int:smoId>/', views.edit_smo, name='edit_smo'),
        # path(f'{hashed_url("delete_smo")}/<int:smoId>/', views.delete_smo, name='delete_smo'), 
        path('delete_smo/<int:smoId>/', views.delete_smo, name='delete_smo'), 
        path(f'{hashed_url("view_smo")}/<int:smoId>/', views.view_smo, name='view_smo'),
        path(f'{hashed_url("SMO")}/', views.SMO, name='SMO'),
        path(f'{hashed_url("smo_excel")}/', views.smo_excel, name='smo_excel'),
        # path(f'{hashed_url("amc_least")}/', views.amc_least, name='amc_least'),
        path(f'{hashed_url("post_report")}/', views.post_report, name='post_report'), 
        path(f'{hashed_url("add_post")}/', views.add_post, name='add_post'),
        path(f'{hashed_url("addpost")}/', views.addpost, name='addpost'),
        path(f'{hashed_url("edit_post")}/<int:id>/', views.edit_post, name='edit_post'),
        # path(f'{hashed_url("delete_post")}/<int:id>/', views.delete_post, name='delete_post'),
        path('delete_post/<int:id>/', views.delete_post, name='delete_post'),
        path(f'{hashed_url("smo")}/renew/', views.renew_smo_plan, name='renew_smo_plan'),
        
        path(f'{hashed_url("SEO")}/', views.SEO, name='SEO'),
        path(f'{hashed_url("add_seo")}/', views.add_seo, name='add_seo'),
        path(f'{hashed_url("addseo")}/', views.addseo, name='addseo'),
        path(f'{hashed_url("edit_seo")}/<int:smoId>/', views.edit_seo, name='edit_seo'),
        path(f'{hashed_url("view_seo")}/<int:smoId>/', views.view_seo, name='view_seo'),
        path(f'{hashed_url("seo")}/renew/', views.renew_seo_plan, name='renew_seo_plan'),
        
    # task
        path(f'{hashed_url("project_report")}/<int:userId>/', views.project_report, name='project_report'),
        path(f'{hashed_url("addproject")}/', views.addproject, name='addproject'),
        path(f'{hashed_url("add_project")}/', views.add_project, name='add_project'),
        path(f'{hashed_url("edit_project")}/<int:pj_id>/', views.edit_project, name='edit_project'), 
        # path(f'{hashed_url("delete_project")}/<int:pj_id>/', views.delete_project, name='delete_project'),
        path('delete_project/<int:pj_id>/', views.delete_project, name='delete_project'),

        path(f'{hashed_url("view_project")}/<int:pj_id>/', views.view_project, name='view_project'),  
        # path(f'{hashed_url("complete_project")}/<int:pj_id>/', views.complete_project, name='complete_project'),
        # path(f'{hashed_url("running_project")}/<int:pj_id>/', views.running_project, name='running_project'),  
        path('complete_project/<int:pj_id>/', views.complete_project, name='complete_project'),  
        path('running_project/<int:pj_id>/', views.running_project, name='running_project'),  

        path(f'{hashed_url("project_list")}/', views.project_list, name='project_list'),
        path(f'{hashed_url("project_excel")}/', views.project_excel, name='project_excel'),
        
        path(f'{hashed_url("add_task")}/', views.add_task, name='add_task'),
        # path(f'{hashed_url("update_task_remark")}/<int:taskId>/', views.update_task_remark, name='update_task_remark'), 
        path('update_task_remark/<int:taskId>/', views.update_task_remark, name='update_task_remark'), 

        # path(f'{hashed_url("fetch_users_for_assign_to")}/', views.fetch_users_for_assign_to, name='fetch_users_for_assign_to'), 
        path('fetch_users_for_assign_to/', views.fetch_users_for_assign_to, name='fetch_users_for_assign_to'), 

        path(f'{hashed_url("add_new_task")}/', views.add_new_task, name='add_new_task'),
        path(f'{hashed_url("edit_task")}/<int:taskId>/', views.edit_task, name='edit_task'),
        # path(f'{hashed_url("delete_task")}/<int:taskId>/', views.delete_task, name='delete_task'),
        path('delete_task/<int:taskId>/', views.delete_task, name='delete_task'),

        path(f'{hashed_url("complete_task")}/<int:task_id>/', views.complete_task, name='complete_task'),
        # path(f'{hashed_url("rewaise_task")}/<int:task_id>/', views.rewaise_task, name='rewaise_task'),
        path('rewaise_task/<int:task_id>/', views.rewaise_task, name='rewaise_task'),

        path(f'{hashed_url("task_list")}/', views.task_list, name='task_list'),
        path(f'{hashed_url("task_view")}/<int:userId>/', views.task_view, name='task_view'),
        path(f'{hashed_url("Urgent_task")}/', views.Urgent_task, name='Urgent_task'),
        path(f'{hashed_url("completed_task")}/', views.completed_task, name='completed_task'),
        path(f'{hashed_url("revise_task")}/', views.revise_task, name='revise_task'),
        path(f'{hashed_url("task_report")}/', views.task_report, name='task_report'),
        path(f'{hashed_url("task_excel")}/', views.task_excel, name='task_excel'),
        path(f'{hashed_url("view_task")}/<int:taskId>/', views.view_task, name='view_task'),
        
        path(f'{hashed_url("my_task")}/', views.my_task, name='my_task'),
        path(f'{hashed_url("my_urgent_task")}/', views.my_urgent_task, name='my_urgent_task'),
        path(f'{hashed_url("my_completed_task")}/', views.my_completed_task, name='my_completed_task'),
        path(f'{hashed_url("my_revise_task")}/', views.my_revise_task, name='my_revise_task'),
        
        path(f'{hashed_url("add_meeting")}/', views.add_meeting, name='add_meeting'),
        path(f'{hashed_url("addmeeting")}/', views.addmeeting, name='addmeeting'),
        path(f'{hashed_url("edit_meeting")}/<int:meet_id>/', views.edit_meeting, name='edit_meeting'),
        # path(f'{hashed_url("delete_meeting")}/<int:meet_id>/', views.delete_meeting, name='delete_meeting'),
        path('delete_meeting/<int:meet_id>/', views.delete_meeting, name='delete_meeting'),

        path(f'{hashed_url("meeting_list")}/', views.meeting_list, name='meeting_list'),
        path(f'{hashed_url("meeting_excel")}/', views.meeting_excel, name='meeting_excel'),
        
        path(f'{hashed_url("add_report")}/', views.add_report, name='add_report'),
        path(f'{hashed_url("add_daily_report")}/', views.add_daily_report, name='add_daily_report'),
        path(f'{hashed_url("daily_report")}/', views.daily_report, name='daily_report'),
        path(f'{hashed_url("user_report")}/<int:userId>/', views.user_report, name='user_report'),
        path(f'{hashed_url("edit_report")}/<int:repoId>/', views.edit_report, name='edit_report'),
        path(f'{hashed_url("edit_daily_report_record")}/<int:repoId>/', views.edit_daily_report_record, name='edit_daily_report_record'),
        path(f'{hashed_url("view_report")}/<int:repoId>/', views.view_report, name='view_report'),
        # path(f'{hashed_url("delete_daily_report")}/<int:repoId>/', views.delete_daily_report, name='delete_daily_report'),
        path('delete_daily_report/<int:repoId>/', views.delete_daily_report, name='delete_daily_report'),

        path(f'{hashed_url("report_download")}/', views.report_download, name='report_download'),
        path(f'{hashed_url("daily_excel")}/', views.daily_excel, name='daily_excel'),
        
    # HRMS
        path(f'{hashed_url("add_employee")}/', views.add_employee, name='add_employee'),
        path(f'{hashed_url("add_employee_onboarding")}/', views.add_employee_onboarding, name='add_employee_onboarding'),
        path(f'{hashed_url("edit_employee")}/<int:emp_id>/', views.edit_employee, name='edit_employee'),
        # path(f'{hashed_url("delete_employee_onboarding")}/<int:emp_id>/', views.delete_employee_onboarding, name='delete_employee_onboarding'),
        path('delete_employee_onboarding/<int:emp_id>/', views.delete_employee_onboarding, name='delete_employee_onboarding'),

        path(f'{hashed_url("employee_list")}/', views.employee_list, name='employee_list'),
        path(f'{hashed_url("employee_details")}/<int:emp_id>/', views.employee_details, name='employee_details'),
        
        path(f'{hashed_url("add_intern")}/', views2.add_intern, name='add_intern'),
        path(f'{hashed_url("add_intern_onboarding")}/', views2.add_intern_onboarding, name='add_intern_onboarding'),
        path(f'{hashed_url("edit_intern")}/<int:intern_id>/', views2.edit_intern, name='edit_intern'),
        # path(f'{hashed_url("delete_intern_onboarding")}/<int:intern_id>/', views2.delete_intern_onboarding, name='delete_intern_onboarding'),
        path('delete_intern_onboarding/<int:intern_id>/', views2.delete_intern_onboarding, name='delete_intern_onboarding'),

        path(f'{hashed_url("intern_list")}/', views2.intern_list, name='intern_list'),
        path(f'{hashed_url("intern_details")}/<int:emp_id>/', views2.intern_details, name='intern_details'),
        path(f'{hashed_url("details_count_intern")}/', views2.details_count_intern, name='details_count_intern'),
        path(f'{hashed_url("intern_excel")}/', views2.intern_excel, name='intern_excel'),

        # path(f'{hashed_url("intern_details")}/<int:emp_id>/', views.intern_details, name='intern_details'),

        path(f'{hashed_url("details_count")}/', views.details_count, name='details_count'),
        path(f'{hashed_url("emp_excel")}/', views.emp_excel, name='emp_excel'),
        
        path(f'{hashed_url("approved_leave")}/', views.approved_leave, name='approved_leave'),
        path(f'{hashed_url("rejected_leave")}/', views.rejected_leave, name='rejected_leave'),
        path(f'{hashed_url("pending_leave")}/', views.pending_leave, name='pending_leave'),
        path(f'{hashed_url("approve_leave")}/<int:leave_id>/', views.approve_leave, name='approve_leave'),
        path(f'{hashed_url("reject_leave")}/<int:leave_id>/', views.reject_leave, name='reject_leave'),
        path('delete_leave/<int:leave_id>/', views.delete_leave, name='delete_leave'),

        path('del_leave/<int:leave_id>/', views.del_leave, name='del_leave'), 
        path(f'{hashed_url("view_leave")}/<int:leave_id>/', views.view_leave, name='view_leave'),
        path(f'{hashed_url("edit_leave")}/<int:leave_id>/', views.edit_leave, name='edit_leave'),
        
        path(f'{hashed_url("addleave")}/', views.addleave, name='addleave'),
        path(f'{hashed_url("add_leave")}/', views.add_leave, name='add_leave'),
        path(f'{hashed_url("hiring_list")}/', views2.hiring_list, name='hiring_list'),
        path(f'{hashed_url("career_view")}/<int:id>/', views2.view_hiring, name='view_hiring'),
        path(f'{hashed_url("hiring_status")}/<int:id>/', views2.hiring_status, name='hiring_status'),
        path(f'{hashed_url("update")}-status/<int:id>/', views2.update_applicant_status, name='update_applicant_status'),
        path(f'{hashed_url("add_hiring")}/', views2.add_hiring, name='add_hiring'),
        # path(f'{hashed_url("delete_hiring")}/<int:id>/', views2.delete_hiring, name='delete_hiring'),
        path('delete_hiring/<int:id>/', views2.delete_hiring, name='delete_hiring'),


        path(f'{hashed_url("open_letter_least")}/', views.open_letter_least, name='open_letter_least'),
        # path(f'{hashed_url("download_experience_letter")}/<int:employee_id>/', views.download_experience_letter, name='download_experience_letter'),
        # path(f'{hashed_url("download_appointment_letter")}/<int:employee_id>/', views.download_appointment_letter, name='download_appointment_letter'),
        # path(f'{hashed_url("download_offer_letter")}/<int:employee_id>/', views.download_offer_letter, name='download_offer_letter'),
        # path(f'{hashed_url("download_bond_letter")}/<int:employee_id>/', views.download_bond_letter, name='download_bond_letter'),
        
        # path(f'{hashed_url("download_intern_offer_letter")}/<int:intern_id>/', views.download_intern_offer_letter, name='download_intern_offer_letter'),
        # path(f'{hashed_url("download_intern_appointment_letter")}/<int:intern_id>/', views.download_intern_appointment_letter, name='download_intern_appointment_letter'),
        # path(f'{hashed_url("download_intern_experience_letter")}/<int:intern_id>/', views.download_intern_experience_letter, name='download_intern_experience_letter'),
        path('download_experience_letter/<int:employee_id>/', views.download_experience_letter, name='download_experience_letter'),
        path('download_appointment_letter/<int:employee_id>/', views.download_appointment_letter, name='download_appointment_letter'),
        path('download_offer_letter/<int:employee_id>/', views.download_offer_letter, name='download_offer_letter'),
        path('download_bond_letter/<int:employee_id>/', views.download_bond_letter, name='download_bond_letter'),
        
        path('download_intern_offer_letter/<int:intern_id>/', views.download_intern_offer_letter, name='download_intern_offer_letter'),
        path('download_intern_appointment_letter/<int:intern_id>/', views.download_intern_appointment_letter, name='download_intern_appointment_letter'),
        path('download_intern_experience_letter/<int:intern_id>/', views.download_intern_experience_letter, name='download_intern_experience_letter'),


        path(f'{hashed_url("open_payroll_least")}/', views.open_payroll_least, name='open_payroll_least'),
        path(f'{hashed_url("monthly_report_list")}/', views.monthly_report_list, name='monthly_report_list'),
        # path(f'{hashed_url("download_report_file")}/', views.download_report_file, name='download_report_file'),
        path(f'{hashed_url("download")}-report-file/<str:filename>/', views.download_report_file, name='download_report_file'),
        
        # path(f'{hashed_url("delete_monthly_report")}/<int:report_id>/', views.delete_monthly_report, name='delete_monthly_report'),
        path('delete_monthly_report/<int:report_id>/', views.delete_monthly_report, name='delete_monthly_report'),

        path(f'{hashed_url("download_monthly_report_all_employees")}/', views.download_monthly_report_all_employees, name='download_monthly_report_all_employees'),
        path(f'{hashed_url("add_attendance_sheet")}/', views.add_attendance_sheet, name='add_attendance_sheet'),
        path(f'{hashed_url("salary")}/<int:emp_id>/', views.salary, name='salary'),
        path(f'{hashed_url("attendance_count")}/', views.attendance_count, name='attendance_count'),
        path(f'{hashed_url("salary_slip")}/', views.salary_slip, name='salary_slip'),
        path(f'{hashed_url("salary_slip_")}/', views.salary_slip_, name='salary_slip_'),
        
        
        path(f'{hashed_url("advance_salary")}/', views.advance_salary, name='advance_salary'),
        path(f'{hashed_url("add_salary")}/', views.add_salary, name='add_salary'),
        path(f'{hashed_url("edit_salary")}/<int:s_id>/', views.edit_salary, name='edit_salary'),
        # path(f'{hashed_url("delete_salary")}/<int:s_id>/', views.delete_salary, name='delete_salary'),
        path('delete_salary/<int:s_id>/', views.delete_salary, name='delete_salary'),


    #puresaas
        path(f'{hashed_url("plan")}/', views2.plan, name='plan'),
        path(f'{hashed_url("add_plan")}/', views2.add_plan, name='add_plan'),
        path(f'{hashed_url("edit_plan")}/<int:id>/', views2.edit_plan, name='edit_plan'), 
        # path(f'{hashed_url("delete_plan")}/<int:id>/', views2.delete_plan, name='delete_plan'), 
        path('delete_plan/<int:id>/', views2.delete_plan, name='delete_plan'), 

        path(f'{hashed_url("view_plan")}/<int:id>/', views2.view_plan, name='view_plan'), 
        # path(f'{hashed_url("plan_view")}/', views2.plan_view, name='plan_view'), 
        # path(f'{hashed_url("monthly_plan_view")}/', views2.monthly_plan_view, name='monthly_plan_view'),
        path('plan_view/', views2.plan_view, name='plan_view'), 
        path('monthly_plan_view/', views2.monthly_plan_view, name='monthly_plan_view'),

    # puresaas Inquiry
        path(f'{hashed_url("free_trial")}/', views2.free_trial, name='free_trial'),
        path('freetrial/<int:id>/', views2.freetrial, name='freetrial'),
        
        path(f'{hashed_url("request_call")}/', views2.request_call, name='request_call'),
        path('requestcall/<int:id>/', views2.requestcall, name='requestcall'),
        path(f'{hashed_url("view_call")}/<int:id>/', views2.view_call, name='view_call'),
        
        path(f'{hashed_url("price_quote")}/', views2.price_quote, name='price_quote'),
        path('pricequote/<int:id>/', views2.pricequote, name='pricequote'),
        path(f'{hashed_url("view_quote")}/<int:id>/', views2.view_quote, name='view_quote'),
        
        path(f'{hashed_url("book_demo")}/', views2.book_demo, name='book_demo'),
        path('bookdemo/<int:id>/', views2.bookdemo, name='bookdemo'),
        
        path(f'{hashed_url("ask_question")}/', views2.ask_question, name='ask_question'),
        path('askquestion/<int:id>/', views2.askquestion, name='askquestion'),
        
        path(f'{hashed_url("blogs_comment")}/', views2.blogs_comment, name='blogs_comment'),
        path('blogscomment/<int:id>/', views2.blogscomment, name='blogscomment'),
        
        path(f'{hashed_url("message")}/', views2.message, name='message'),
        path('del_message/<int:id>/', views2.del_message, name='del_message'),
        
        path(f'{hashed_url("all_demo")}/', views2.all_demo, name='all_demo'),
        path(f'{hashed_url("del_all_demo")}/<int:id>/', views2.del_all_demo, name='del_all_demo'),
        path(f'{hashed_url("view_demo")}/<int:id>/', views2.view_demo, name='view_demo'),
        # path(f'{hashed_url("demo_convert_lead")}/<int:id>/', views2.demo_convert_lead, name='demo_convert_lead'),
        # path(f'{hashed_url("book_bulk_convert")}/', views2.book_bulk_convert, name='book_bulk_convert'),
        path('demo_convert_lead/<int:id>/', views2.demo_convert_lead, name='demo_convert_lead'),
        path('book_bulk_convert/', views2.book_bulk_convert, name='book_bulk_convert'),
        
    # puresaas
        path(f'{hashed_url("puresaas_list")}/', views2.puresaas_list, name='puresaas_list'),
        path(f'{hashed_url("puresaas_renewal")}/', views2.puresaas_renewal, name='puresaas_renewal'),
        path(f'{hashed_url("puresaas_renewal_week")}/', views2.puresaas_renewal_week, name='puresaas_renewal_week'),
        path(f'{hashed_url("puresaas_view")}/<int:id>/', views2.puresaas_view, name='puresaas_view'),
        path(f'{hashed_url("pure_view")}/<int:id>/', views2.pure_view, name='pure_view'),
        path(f'{hashed_url("puresaas_client")}/<int:id>/', views2.puresaas_client, name='puresaas_client'),
        
    # SIT Career
        path('sit_career/', views2.sit_career, name='sit_career'),
        path(f'{hashed_url("send_tomorrow_meeting_reminders")}/', views2.send_tomorrow_meeting_reminders, name='send_tomorrow_meeting_reminders'),
        path(f'{hashed_url("toggle_active_user")}/<int:user_id>/', views2.toggle_active_user, name='toggle_active_user'),

    # salary history
        path(f'{hashed_url("salary_history")}/', views2.salary_history, name='salary_history'),
        path(f'{hashed_url("add_salary_history")}/', views2.add_salary_history, name='add_salary_history'),
        path(f'{hashed_url("salary_history_list")}/', views2.salary_history_list, name='salary_history_list'),
        path(f'{hashed_url("edit_salary_history")}/<int:id>/', views2.edit_salary_history, name='edit_salary_history'),
        # path(f'{hashed_url("delete_salary_history")}/<int:id>/', views2.delete_salary_history, name='delete_salary_history'),
        path('delete_salary_history/<int:id>/', views2.delete_salary_history, name='delete_salary_history'),
        path(f'{hashed_url("salary_record")}/', views2.salary_record, name='salary_record'),
        path(f'{hashed_url("add_salary_record")}/<int:emp_id>/', views2.add_salary_record, name='add_salary_record'),
        path(f'{hashed_url("edit_salary_record")}/<int:id>/<int:emp_id>/', views2.edit_salary_record, name='edit_salary_record'),
        # path(f'{hashed_url("api/get_session_data")}/', views.get_session_data, name='get_session_data'),
        path('api/get_session_data/', views.get_session_data, name='get_session_data'),

        
]  + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

# backed up when i was hashing url