# crm/session_utils.py

def get_client_ip(request):
    """Utility to extract IP address from request."""
    x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
    if x_forwarded_for:
        ip = x_forwarded_for.split(',')[0]
    else:
        ip = request.META.get('REMOTE_ADDR')
    return ip

def set_user_session(request, user):
    from datetime import timedelta
    from django.utils import timezone
    from crm.models import tbl_messages
    # from crm.utils import get_client_ip  # adjust if your method is elsewhere

    request.session.flush()  # Clear old session

    # Set all session variables
    full_name = f"{user.get('name', '')} {user.get('middle_name', '')} {user.get('last_name', '')}".strip()

    session_data = {
        'intern_id': user.get('intern_id'),
        'emp_type': user.get('emp_type'),
        'session_id': user['userId'],
        'session_user': full_name,
        'session_roleid': user['role_id'].split(',') if user.get('role_id') else [],
        'department_id': user['dp_id'].split(',') if user.get('dp_id') else [],
        'user_compney': user.get('company_name', ''),
        'company_id': user.get('company_id'),
        'head_id': user.get('head_id'),
        'session_rolename': user.get('role_name'),
        'session_mobile': user.get('mobile'),
        'session_empId': user.get('emp_id'),
        'session_emp_type': user.get('emp_type'),
        'is_active': user.get('is_active'),
    }

    # Set into request.session
    for k, v in session_data.items():
        request.session[k] = v

    # Create login message
    ip_address = get_client_ip(request)
    tbl_messages.objects.create(
        message_name=full_name,
        change_status="Login Successfully.",
        added_date=timezone.now() + timedelta(hours=5, minutes=30),
        company_id=user.get('company_id'),
        user_id=user.get('userId'),
        ip_address=ip_address,
    )

    return session_data  # Useful for debugging/logging
