def session_variables(request):
    return {
        'session_user': request.session.get('session_user', ''),
        'session_emp_type': request.session.get('session_emp_type', ''),
        'session_rolename': request.session.get('session_rolename', ''),
        'intern_id': request.session.get('intern_id', ''),
    }
